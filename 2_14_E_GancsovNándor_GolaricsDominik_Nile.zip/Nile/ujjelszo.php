<div id="ujjelszo-tartalom">
    <label>Régi jelszó</label> 
    <input type="password" id="regijelszo">
    <label>Új jelszó</label> 
    <input type="password" id="ujjelszo">
    <label>Új jelszó újra</label> 
    <input type="password" id="ujjelszoujra">
    <br>
    <button id="ujjelszomentes" name="ujjelszomentes">Jelszó megváltoztatása</button>
</div>
