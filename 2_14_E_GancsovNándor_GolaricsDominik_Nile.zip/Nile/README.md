Maga a cipő/termék

--Név

--Márka

--Ár

--Termék megejelenése dátum

--Raktáron(bool)

--Méret

--kep url

--típus


-Márka tábla
-Méret tábla()
-Típus tábla

---
Felhasználó

-Felh név

-Jelszó (kódolva, SHA256)

-email

-fiók készítése dátum

--Kiszállítási cím

--Telefon

--Számlázási cím


Fejlesztői dokumentáció: adatbázis etc

Felhasználói dokumentáció: oldal használása