<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><img src="hatter/asd.jpg" alt=""></img>Aréna Klub</title>
    <link rel="stylesheet" href="css/css.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
     <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>

</head>
<body>
    <?php
    session_start();
    require_once "connection/connection.php";
    
    $page = isset($_GET['page']) ? $_GET['page'] : 'Fooldal';
    $stmt = $conn->prepare("SELECT content FROM pages WHERE title = ?");
    $stmt->bind_param("s", $page);
    $stmt->execute();
    $pageResult = $stmt->get_result();
    $pageData = $pageResult->fetch_assoc();
    
    $contentFile = "oldalak/" . ($pageData['content'] ?? 'fooldal');
    ?>
    
    <!-- Fejléc -->
    <header>
        <div class="logo">ARÉNA KLUB</div>
        <div class="mobil-menu" style="display: none;">
            <div class="menu-icon" id="mobilMenuIcon"><i class="fas fa-bars"></i></div>   
        </div>
        <nav>
            <ul>
                <li><a href="?page=Fooldal" class="fooldal">Kezdőlap</a></li>
                <li><a href="?page=Szobak" class="szobak">Szobák</a>
                <li><a href="?page=Profil" class="profils">Profilom</a></li>
                <li><a href="?page=Erdekesseg" class="erdekesseg">Erdekesseg</a></li>
                <li><a href="?page=Hírek" class="erdekesseg">Hírek</a></li>
                <li><a href="?page=Kilépés" class="kilepes">Kilépés</a></li>
            </ul>
            <div class="menu-icon" id="menuIcon"><i class="fas fa-bars"></i></div>
        </nav>
    </header>
    
 
    
    <main class="content">
        <?php
        if (file_exists($contentFile)) {
            include($contentFile);
        } else {
           echo "<p>Ez a tartalom nem elérhető!</p>";
        } 
        ?>
    </main>
    <?php if (isset($_SESSION['id'])): ?>
    <div id="cseveges-kapcsolo">💬</div> <!-- Csevegés ikon -->
    <div id="cseveges-doboz" style="display: none;">
        <div id="cseveges-fejlec">Kérj segítséget <span id="cseveges-bezar">×</span></div>
        <div id="cseveges-uzenetek"></div> <!-- Üzenetek megjelenítése -->
        
        <div id="cseveges-beviteli-terulet">
            <input 
                type="text" 
                id="jelentes-cim" 
                placeholder="Jelentés címe (csak első alkalommal)" 
                autocomplete="off"
            /> <!-- Jelentés címe, ha új jelentés jön létre -->
            
            <input 
                type="text" 
                id="cseveges-bevitel" 
                placeholder="Írj egy üzenetet..." 
                autocomplete="off"
            /> 

            <button id="cseveges-kuldes">Küldés</button> 
        </div>
    </div>
<?php endif; ?>







    <?php if (!isset($_SESSION['id'])): ?>
        <div class="element">
            <div class="bejelentkezes">
                Kedves felhasználó, nem jelentkeztél be. Ahhoz, hogy további tartalmat érj el:
                <div class="bejelentkezes_szoveg2">
                    <a href="/login" class="megerosites-gomb">Jelentkezz be!</a>
                </div>
            </div>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['id'])): ?>
        <div class="megerosites">
            <div class="bejelentkezes">
                Kedves felhasználó, nem erősítetted meg a fiókodat. Ahhoz, hogy további tartalmat érj el:
                <div class="bejelentkezes_szoveg2">
                    <a href="?page=Profil" class="megerosites-gomb">Megerősítem!</a>
                </div>
            </div>
        </div>
    <?php endif; ?>
    
  
    
    <script src="Javascripts/js.js"></script>
    <script src="Javascripts/user-adats.js"></script>
    <script src="Javascripts/felhasznaloi.js"></script>
</body>
</html>