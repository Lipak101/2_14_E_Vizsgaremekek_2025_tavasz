<?php
require_once("../connection/connection.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $rawNev = $_POST['Nev'] ?? '';
    $rawJelszo = $_POST['Jelszo'] ?? '';
    $rawEmail = $_POST['email'] ?? '';

    $nev = trim($rawNev);
    $jelszo = trim($rawJelszo);
    $email = trim($rawEmail);

    $emailPattern = "/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/";
    if (!preg_match($emailPattern, $email)) {
        echo "<script>alert('Érvénytelen email formátum!'); window.history.back();</script>";
        exit();
    }

    if (!preg_match("/^[a-zA-Z0-9_áéíóöőúüűÁÉÍÓÖŐÚÜŰ]{3,20}$/u", $nev)) {
        echo "<script>alert('A felhasználónév csak betűket, számokat és aláhúzást tartalmazhat (3-20 karakter), beleértve a magyar ékezetes karaktereket is!'); window.history.back();</script>";
        exit();
    }

    $nev = mysqli_real_escape_string($conn, $nev);
    $jelszo = mysqli_real_escape_string($conn, $jelszo);
    $email = mysqli_real_escape_string($conn, $email);

    $stmt = $conn->prepare("SELECT email, nev FROM felhasznalo WHERE email = ? OR nev = ?");
    if (!$stmt) {
        die("SQL előkészítési hiba: " . $conn->error);
    }

    $stmt->bind_param("ss", $email, $nev);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($existingEmail, $existingNev);
        $stmt->fetch();

        if ($email === $existingEmail) {
            echo "<script>alert('Ez az email már foglalt!'); window.history.back();</script>";
            exit();
        } elseif ($nev === $existingNev) {
            echo "<script>alert('Ez a felhasználónév már foglalt!'); window.history.back();</script>";
            exit();
        }
    }

    $stmt->close();

    $hashedPassword = password_hash($jelszo, PASSWORD_DEFAULT);
    $mysqltime = date('Y-m-d H:i:s');
    $rnd = rand(1000, 9999);

    $stmt = $conn->prepare("INSERT INTO felhasznalo 
        (nev, jelszo, email, aktív, Szerep, megerositve, kod, datum, utolso_bejelentkezes, utoljara_hasznalt_ip, elrontott_bejelenkezes) 
        VALUES (?, ?, ?, 1, 0, 0, ?, ?, NULL, NULL, 0)");

    if (!$stmt) {
        die("SQL beszúrási hiba: " . $conn->error);
    }

    $stmt->bind_param("sssis", $nev, $hashedPassword, $email, $rnd, $mysqltime);

    if ($stmt->execute()) {
        echo "<script>
            alert('Sikeres regisztráció!');
            window.location.href = '/Login';
        </script>";
        exit();
    } else {
        echo "<script>alert('Hiba történt a regisztráció során!'); window.history.back();</script>";
    }

    $stmt->close();
}
?>
