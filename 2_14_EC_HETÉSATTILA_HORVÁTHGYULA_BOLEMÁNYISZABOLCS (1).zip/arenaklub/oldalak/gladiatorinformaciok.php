
<link rel="stylesheet" href="css/style.css">
<body>
    <fejlec>
        <nav>
        </nav>
    </fejlec>
    <div class="korhinta">

        <div class="lista">
            <div class="elem">
                <img src="kepek/wallpaperflare.com_wallpaper.jpg">
                <div class="tartalom">
                    <div class="cim">A gladiátorok élete</div>
                    <div class="leiras">
                       A gladiátorok az ókori Róma rettegett és tisztelt alakjai voltak, akik kegyetlen harcokban szórakoztatták a népet. Sok gladiátor rabszolga, hadifogoly vagy bűnöző volt, akiket kényszerítettek a küzdelemre. Néhányan azonban önként jelentkeztek, vonzotta őket a hírnév, a pénz vagy a szabadulás reménye. A gladiátorok szigorú kiképzésen mentek keresztül a ludi nevű iskolákban, ahol fizikailag és mentálisan is felkészítették őket. Az életük állandó küzdelem volt a túlélésért, hiszen az arénában az egyik fél gyakran halállal fizetett. Mindez az emberek szórakoztatására történt, a gladiátorok számára pedig ez a mindennapok része volt.
                    </div>
                    <div class="gombok">
                         <a href="https://gladiator.fandom.com/wiki/Gladiator" target="_blank">
                        <button>TOVÁBBI INFORMÁCIÓ</button>
                        </a>
                    </div>
                </div>
            </div>
            <div class="elem">
                <img src="kepek/wallpaperflare.com_wallpaper (3).jpg">
                <div class="tartalom">
                    <div class="cim">A gladiátor játékok</div>
                    <div class="leiras">
                        A gladiátori játékok az ókori Róma egyik legnépszerűbb látványosságai voltak. Az arénában, mint például a Colosseumban, gladiátorok élet-halál harcot vívtak a közönség szórakoztatására. A játékokat pompás felvonulások nyitották meg, majd következtek a harcok, ahol a küzdők különböző fegyverekkel és harci stílusokkal mérték össze erejüket. Egyes harcok halálos kimenetelűek voltak, bár nem minden összecsapás végződött halállal. A tömeg sorsdöntő szerepet játszott, hiszen a nézők néha szavaztak, hogy megkíméljék-e a vesztes életét. A gladiátor játékok egyszerre jelentettek szórakozást és hatalmi demonstrációt a római birodalomban.
                    </div>
                    <div class="gombok">
                         <a href="https://gladiator.fandom.com/wiki/Gladiator" target="_blank">
                        <button>TOVÁBBI INFORMÁCIÓ</button>
                        </a>
                    </div>
                </div>
            </div>
            <div class="elem">
                <img src="kepek/wallpaperflare.com_wallpaper (2).jpg">
                <div class="tartalom">
                    <div class="cim">Érdekes tények </div>
                    <div class="leiras">
                        A gladiátori játékok nem mindig voltak halálosak – a legtöbb harc életben hagyta a veszteseket, főleg ha jól küzdöttek. A gladiátorok néha híressé váltak, és szinte szupersztárként kezelték őket, ajándékokat kaptak, és egyesek még szabadulásukat is kivívták. Nemcsak férfiak, hanem nők is küzdöttek gladiátorként, bár ők ritkábbak voltak. Az arénában különféle egzotikus állatok is szerepeltek, mint oroszlánok, tigrisek és elefántok, amelyekkel a gladiátoroknak szembe kellett nézniük. A közönség gyakran dönthetett a vesztesek sorsáról: "pollice verso" – a hüvelykujj jele szerint halál vagy kegyelem várt rájuk.
                    </div>
                    <div class="gombok">
                         <a href="https://gladiator.fandom.com/wiki/Gladiator" target="_blank">
                        <button>TOVÁBBI INFORMÁCIÓ</button>
                        </a>
                    </div>
                </div>
            </div>
            <div class="elem">
                <img src="kepek/wallpaperflare.com_wallpaper (1).jpg">
                <div class="tartalom">
                    <div class="cim">Rólunk</div>
                    <div class="leiras">
                    Mi vagyunk az Aréna Klub fejlesztői gárdálya: Bolemányi Szabolcs, Hetés Attila és Horváth Gyula, a Szily Kálmán Technikum tanulói.  
                    Projektünk célja egy olyan fórum létrehozása, ahol a gladiátorok világát kedvelő felhasználók szabadon megoszthatják gondolataikat, élményeiket és véleményüket.  
                    Ez a platform lehetőséget biztosít arra, hogy a gladiátor témájú tartalmak iránt érdeklődők egy közösséggé kovácsolódjanak, és kiélhessék szenvedélyüket egy modern, könnyen kezelhető felületen.

                </div>
                <div class="gombok">
                         <a href="https://gladiator.fandom.com/wiki/Gladiator" target="_blank">
                        <button>TOVÁBBI INFORMÁCIÓ</button>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="elonezet">
            <div class="elem">
                <img src="kepek/wallpaperflare.com_wallpaper.jpg">
                <div class="tartalom">
                    <div class="cim">A gladiátorok élete</div>
                </div>
            </div>
            <div class="elem">
                <img src="kepek/wallpaperflare.com_wallpaper (3).jpg">
                <div class="tartalom">
                    <div class="cim">A gladiátori játékok</div>
                </div>
            </div>
            <div class="elem">
                <img src="kepek/wallpaperflare.com_wallpaper (2).jpg">
                <div class="tartalom">
                    <div class="cim">Érdekes tények </div>
                </div>
            </div>
            <div class="elem">
                <img src="kepek/wallpaperflare.com_wallpaper (1).jpg">
                <div class="tartalom">
                    <div class="cim">Rólunk</div>
                    
                </div>
            </div>
        </div>
        <div class="nyilak">
            <button id="elozo"><</button>
            <button id="kovetkezo">></button>
        </div>
        <div class="ido"></div>
    </div>
    <script src="Javascripts/user-adats.js"></script>
    <script src="Javascripts/informaciok.js"></script>
