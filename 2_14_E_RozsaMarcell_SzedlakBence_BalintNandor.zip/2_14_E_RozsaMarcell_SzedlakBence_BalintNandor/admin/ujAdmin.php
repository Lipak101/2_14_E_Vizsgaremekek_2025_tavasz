<?php
if (!isset($_SESSION['belepett'])) {
    header("Location: index.php");
    exit();
}

include('includes/dbvezerlo.php');
$db = new DBVezerlo();

function jelszoEros($jelszo) {
    return preg_match('/^(?=.*[A-Za-z])(?=.*\d)(?=.*[\W_]).{8,}$/', $jelszo);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fnev = $_POST['fnev'] ?? '';
    $passwd = $_POST['passwd'] ?? '';
    $passwd_megerosit = $_POST['passwd_megerosit'] ?? '';

    if (empty($fnev) || empty($passwd) || empty($passwd_megerosit)) {
        echo "<div class='alert'>Felhasználónév és jelszó megadása kötelező!</div>";
        exit();
    }

    // Felhasználónév ellenőrzése
    $ellenor_keres = "SELECT id FROM admin WHERE fnev = ?";
    $lekerdezes = $db->executeSelectQuery($ellenor_keres, [$fnev], "s");

    if (!empty($lekerdezes)) {
        echo "<div class='alert'>Ez a felhasználónév már létezik, kérlek válassz másikat!</div>";
        exit();
    }

    if ($passwd !== $passwd_megerosit) {
        echo "<div class='alert'>A jelszavak nem egyeznek!</div>";
        exit();
    }

    if (!jelszoEros($passwd)) {
        echo "<div class='alert'>A jelszónak legalább 8 karakterből kell állnia, tartalmaznia kell betűt, számot és speciális karaktert!</div>";
        exit();
    }

    $hashedPasswd = password_hash($passwd, PASSWORD_DEFAULT);

    $query = "INSERT INTO admin (fnev, passwd) VALUES (?, ?)";
    $params = [$fnev, $hashedPasswd];
    $types = "ss";

    if ($db->executeQuery($query, $params, $types)) {
        echo "<div class='success-msg'>Új adminisztrátor sikeresen hozzáadva!</div>";
        echo "<script>setTimeout(() => location.href='dashboard.php?m=1', 20000);</script>";
    } else {
        echo "<div class='alert'>Hiba történt az adminisztrátor hozzáadásakor.</div>";
    }
}
?>

<div class="admin-form-container" style="width: 50%; margin: 0 auto; padding: 20px; border: 1px solid #ccc; border-radius: 10px;">
    <h3>Új adminisztrátor hozzáadása</h3>
    <form method="POST">
        <div class="form-group">
            <label for="fnev">Felhasználónév:</label>
            <input type="text" name="fnev" required>
        </div>

        <div class="form-group">
            <label for="passwd">Jelszó:</label>
            <input type="password" name="passwd" required>
        </div>

        <div class="form-group">
            <label for="passwd_megerosit">Jelszó megerősítése:</label>
            <input type="password" name="passwd_megerosit" required>
        </div>

        <button type="submit">Adminisztrátor hozzáad
