<?php
session_start();
if (!isset($_SESSION['belepett'])) {
    header("Location: index.php");
    exit();
}

// Kilépés kezelése
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit();
}

$menupont = 1;
if (isset($_GET['m']) && is_numeric($_GET['m'])) {
    $menupont = intval($_GET['m']);
}

// Menü definíció
$menu = [
    ["id" => 1, "nev" => "Dashboard", "title" => "Dashboard"],
    ["id" => 2, "nev" => "Admin hozzáadás", "title" => "Adminisztrátor új"],
    ["id" => 3, "nev" => "Admin jelszó módosítás", "title" => "Adminisztrátor jelszó"],
    ["id" => 4, "nev" => "Kapcsolatkezelés", "title" => "Kapcsolat"]
];

// Tartalom definíció
$tartalom = [
    ["menu_id" => 1, "cim" => "stat", "tartalom" => "Adminisztrátor funkciók"],
    ["menu_id" => 2, "cim" => "Új Adminisztrátor", "tartalom" => "Adminisztrátor regisztráció"],
    ["menu_id" => 3, "cim" => "Jelszó módosítás", "tartalom" => "Jelszómódosítás"],
    ["menu_id" => 4, "cim" => "Kapcsolat", "tartalom" => "Elérhetőség"]
];

if (!in_array($menupont, array_column($menu, 'id'))) {
    $menupont = 1;
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($menu[$menupont - 1]["title"]); ?></title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/ujjarmu.css">
    <link rel="stylesheet" href="css/jarmu_list.css">
    <link rel="stylesheet" href="css/contact.css">
    <link rel="stylesheet" href="css/jelszo.css">
</head>
<body>

<nav>
    <?php foreach ($menu as $item): ?>
        <a href="?m=<?= $item["id"] ?>" class="<?= ($item["id"] == $menupont) ? "active" : "" ?>">
            <?= htmlspecialchars($item["nev"]) ?>
        </a>
    <?php endforeach; ?>
    <a href="?logout=true" class="logout">Kilépés</a>
</nav>

<main>
    <?php foreach ($tartalom as $t): ?>
        <?php if ($t["menu_id"] == $menupont): ?>
            <div class="admin-section-header">
  <h2><?= htmlspecialchars($t["cim"]) ?></h2>
  <p><?= htmlspecialchars($t["tartalom"]) ?></p>
</div>


            <?php if ($menupont == 1 && $t["cim"] == "stat") include('./dashy.php'); ?>
            <?php if ($menupont == 2 && $t["cim"] == "Új Adminisztrátor") include('./ujAdmin.php'); ?>
            <?php if ($menupont == 3 && $t["cim"] == "Jelszó módosítás") include('./adminPassCh.php'); ?>
            <?php if ($menupont == 4 && $t["cim"] == "Kapcsolat") include('./contact.php'); ?>
        <?php endif; ?>
    <?php endforeach; ?>
</main>

</body>
</html>