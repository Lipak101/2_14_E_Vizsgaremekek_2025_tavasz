<?php
if (!isset($_SESSION['belepett'])) {
    header("Location: dashboard.php?m=2");
    exit();
}

// Járművek lekérése az adatbázisból
$dbvez = new DBVezerlo();
$query = "SELECT j.id, j.marka, j.evjarat, j.ar, t.tipus, j.kep FROM jarmuvek j JOIN jarmu_tip t ON j.tipus_id = t.id";
$jarmuvek = $dbvez->executeSelectQuery($query, []);
?>

<section class="jarmu-lista">
    <h2>Járművek listája</h2>

    <?php if (empty($jarmuvek)): ?>
        <p>Nincsenek járművek a rendszerben!</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Márka</th>
                    <th>Évjárat</th>
                    <th>Ár</th>
                    <th>Típus</th>
                    <th>Kép</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($jarmuvek as $jarmu): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($jarmu['marka']); ?></td>
                        <td><?php echo htmlspecialchars($jarmu['evjarat']); ?></td>
                        <td><?php echo number_format($jarmu['ar'], 2, ',', ' '); ?> Ft</td>
                        <td><?php echo htmlspecialchars($jarmu['tipus']); ?></td>
                        <td>
                            <?php if (!empty($jarmu['kep'])): ?>
                                <img src="<?php echo htmlspecialchars($jarmu['kep']); ?>" alt="Jármű kép" width="100">
                            <?php else: ?>
                                <p>Nincs kép</p>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</section>
