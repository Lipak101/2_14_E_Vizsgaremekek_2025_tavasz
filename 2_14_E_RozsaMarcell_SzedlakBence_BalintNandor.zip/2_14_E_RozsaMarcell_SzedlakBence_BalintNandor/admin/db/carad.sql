-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2025. Ápr 15. 09:54
-- Kiszolgáló verziója: 10.4.32-MariaDB
-- PHP verzió: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `carad`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `fnev` varchar(100) NOT NULL,
  `passwd` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `admin`
--

INSERT INTO `admin` (`id`, `fnev`, `passwd`, `email`) VALUES
(1, 'admin', '$2y$10$bL/tW./Dq5I.LyhTtTGT2ueLlyD42exHHE/fT.lDaystvJqP.zbtK', 'admin@gmail.com'),
(3, 'admin2', '$2y$10$akKiFPW2ANlpg7J4xq0ep.8DVgFvCdxGIGZ5H.uC9mH9KUICthdK2', 'admin3@gmail.com'),
(4, 'admin3', '$2y$10$LwnJ9dg/Z0iUXiW/kR.A9uoYug9n5cSGaPZ4zY9/272.w.6S6b0ZC', 'admin7@gmail.com'),
(5, 'admin4', '$2y$10$htz2PXWO83.QiCe3vx89cOLOV0BDz.GWyLq8cmmg/5sjvi7mbaJYm', 'admin4@gmail.com'),
(6, 'admin7', '$2y$10$yCYg3zt3YsFaj.Kqzq6GBOgKYzlS3eSVDbeTgvaX4WySfv7Gttebq', 'admin7@gmail.com');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `cim` tinytext DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `tel` char(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `contact`
--

INSERT INTO `contact` (`id`, `cim`, `Email`, `tel`) VALUES
(1, '1213. Vál Kajászói út 1.', 'steyerzalan@google.com', '+36 01 111 11 5');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `jarmuvek`
--

CREATE TABLE `jarmuvek` (
  `id` int(11) NOT NULL,
  `marka` varchar(100) NOT NULL,
  `evjarat` int(11) NOT NULL,
  `ar` decimal(10,2) NOT NULL,
  `tipus_id` int(11) NOT NULL,
  `kep` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `jarmuvek`
--

INSERT INTO `jarmuvek` (`id`, `marka`, `evjarat`, `ar`, `tipus_id`, `kep`) VALUES
(1, 'BMW', 1995, 17000.00, 2, 'pic/alt/bmv.jpg'),
(2, 'Mercedes', 1973, 19000.00, 2, 'pic/alt/mercedes.jpg'),
(3, 'Ssangyong', 2018, 23000.00, 2, 'pic/alt/ssangyong.jpg'),
(4, 'Jaguar', 1978, 23000.00, 2, 'pic/alt/jaguar.jpg'),
(5, 'velorex', 1970, 100000.00, 2, 'pic/alt/velorex.jpg'),
(6, 'velorex_2', 1970, 100000.00, 2, 'pic/alt/velorex.jpg'),
(7, 'Yaris', 2000, 2000.00, 2, 'pic/alt/yaris.jpg'),
(8, 'yaris_2', 2001, 1900.00, 2, 'pic/alt/yaris.jpg'),
(9, 'BMW2', 1998, 10000.00, 2, 'pic/alt/bmv.jpg'),
(10, 'BMW3', 1996, 14000.00, 2, 'pic/alt/bmv.jpg'),
(11, 'Mercedes_2', 1979, 21500.00, 2, 'pic/alt/mercedes.jpg'),
(12, 'Ssangyong2', 2020, 25000.00, 2, 'pic/alt/ssangyong.jpg'),
(13, 'Mercedes3', 1975, 19800.00, 2, 'pic/alt/mercedes.jpg'),
(14, 'Ssangyong3', 2021, 23000.00, 2, 'pic/alt/ssangyong.jpg'),
(15, 'Ssangyong4', 2020, 20000.00, 2, 'pic/alt/ssangyong.jpg'),
(16, 'Jaguar', 1978, 42000.00, 1, 'pic/sport/jaguar.jpg'),
(17, 'velorexx', 1967, 110000.00, 2, 'pic/alt/velorex.jpg'),
(18, 'Jaguarxc', 1978, 45000.00, 2, 'pic/alt/jaguar.jpg'),
(19, 'BMW', 1996, 2000.00, 1, 'pic/sport/bmv.jpg'),
(20, 'Jaguar', 1970, 60000.00, 1, 'pic/sport/jaguar.jpg'),
(21, 'bőregér', 1967, 200000.00, 1, 'pic/sport/velorex.jpg'),
(22, 'Jaguar6', 1976, 56000.00, 1, 'pic/sport/jaguar.jpg'),
(23, 'Skoda', 1976, 300.00, 2, 'pic/alt/Sk_S100.jpg'),
(24, 'Szedlak', 2025, 123455.00, 1, 'pic/sport/velorex.jpg'),
(25, 'Skoda', 1984, 9000.00, 2, 'pic/alt/skoda120L.JPG'),
(26, 'SKODA2', 1979, 2400.00, 1, 'pic/sport/skoda120L.JPG'),
(27, 'Skoda', 1978, 1233.00, 2, 'pic/alt/skoda120L.JPG');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `jarmu_tip`
--

CREATE TABLE `jarmu_tip` (
  `id` int(11) NOT NULL,
  `tipus` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `jarmu_tip`
--

INSERT INTO `jarmu_tip` (`id`, `tipus`) VALUES
(1, 'sport'),
(2, 'alt');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `konyveles`
--

CREATE TABLE `konyveles` (
  `id` int(11) NOT NULL,
  `KonyvelSzam` bigint(12) DEFAULT NULL,
  `userEmail` varchar(100) DEFAULT NULL,
  `jarmuAzon` int(11) DEFAULT NULL,
  `KezdDat` date DEFAULT NULL,
  `VegDat` date DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `Status` enum('feldolgoz','könyvelt') DEFAULT 'feldolgoz',
  `FelvetelIdeje` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `konyveles`
--

INSERT INTO `konyveles` (`id`, `KonyvelSzam`, `userEmail`, `jarmuAzon`, `KezdDat`, `VegDat`, `message`, `Status`, `FelvetelIdeje`) VALUES
(1, 100001, 'teszt1@carad.hu', 1, '2024-01-10', '2024-01-15', 'Első könyvelés teszt', 'feldolgoz', '2025-04-07 19:17:56'),
(2, 100002, 'teszt2@carad.hu', 2, '2024-02-01', '2024-02-05', 'Második könyvelés', 'könyvelt', '2025-04-07 19:17:56'),
(3, 100003, 'teszt3@carad.hu', 3, '2024-03-12', '2024-03-20', 'Harmadik könyvelés', 'feldolgoz', '2025-04-07 19:17:56'),
(4, 100004, 'teszt4@carad.hu', 4, '2024-04-01', '2024-04-04', 'Negyedik könyvelés', 'könyvelt', '2025-04-07 19:17:56'),
(5, 100005, 'teszt5@carad.hu', 1, '2024-05-10', '2024-05-12', 'Ötödik könyvelés', 'feldolgoz', '2025-04-07 19:17:56'),
(6, 100006, 'teszt6@carad.hu', 2, '2024-06-01', '2024-06-10', 'Hatodik könyvelés', 'könyvelt', '2025-04-07 19:17:56'),
(7, 100007, 'user7@example.com', 1, '2023-01-01', '2023-01-03', 'Bérelve 2 napra', 'könyvelt', '2025-04-14 18:00:40'),
(8, 100008, 'user8@example.com', 2, '2023-02-15', '2023-02-17', 'Bérelve 2 napra', 'könyvelt', '2025-04-14 18:00:40'),
(9, 100009, 'user9@example.com', 3, '2023-03-20', '2023-03-22', 'Bérelve 2 napra', 'könyvelt', '2025-04-14 18:00:40'),
(10, 100010, 'user10@example.com', 4, '2023-04-05', '2023-04-07', 'Bérelve 2 napra', 'könyvelt', '2025-04-14 18:00:40'),
(11, 100011, 'user11@example.com', 5, '2023-05-10', '2023-05-12', 'Bérelve 2 napra', 'könyvelt', '2025-04-14 18:00:40'),
(12, 100012, 'user12@example.com', 6, '2023-06-05', '2023-06-07', 'Bérelve 2 napra', 'könyvelt', '2025-04-14 18:00:40'),
(13, 200007, 'user13@example.com', 1, '2025-01-05', '2025-01-07', 'Bérelve 2 napra', 'könyvelt', '2025-04-14 18:00:40'),
(14, 200008, 'user14@example.com', 2, '2025-02-10', '2025-02-12', 'Bérelve 2 napra', 'könyvelt', '2025-04-14 18:00:40'),
(15, 200009, 'user15@example.com', 3, '2025-03-15', '2025-03-17', 'Bérelve 2 napra', 'könyvelt', '2025-04-14 18:00:40'),
(16, 200010, 'user16@example.com', 4, '2025-04-20', '2025-04-22', 'Bérelve 2 napra', 'könyvelt', '2025-04-14 18:00:40'),
(17, 200011, 'user17@example.com', 5, '2025-05-25', '2025-05-27', 'Bérelve 2 napra', 'könyvelt', '2025-04-14 18:00:40'),
(18, 200012, 'user18@example.com', 6, '2025-06-10', '2025-06-12', 'Bérelve 2 napra', 'könyvelt', '2025-04-14 18:00:40');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `fnev` (`fnev`);

--
-- A tábla indexei `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `jarmuvek`
--
ALTER TABLE `jarmuvek`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_jarmuvek_tipus` (`tipus_id`);

--
-- A tábla indexei `jarmu_tip`
--
ALTER TABLE `jarmu_tip`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `konyveles`
--
ALTER TABLE `konyveles`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT a táblához `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT a táblához `jarmuvek`
--
ALTER TABLE `jarmuvek`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT a táblához `jarmu_tip`
--
ALTER TABLE `jarmu_tip`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `konyveles`
--
ALTER TABLE `konyveles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `jarmuvek`
--
ALTER TABLE `jarmuvek`
  ADD CONSTRAINT `fk_jarmuvek_tipus` FOREIGN KEY (`tipus_id`) REFERENCES `jarmu_tip` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
