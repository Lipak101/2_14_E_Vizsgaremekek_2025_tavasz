<?php
//session_start();
//include('includes/dbvezerlo.php');
//$db = new DBVezerlo();

// Csak belépett admin érheti el
if (!isset($_SESSION['belepett'])) {
    header("Location: index.php");
    exit();
}

$uzenet = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $regiJelszo = $_POST['regi_jelszo'] ?? '';
    $ujJelszo = $_POST['uj_jelszo'] ?? '';
    $ujJelszo2 = $_POST['uj_jelszo2'] ?? '';

    if ($ujJelszo !== $ujJelszo2) {
        $uzenet = "Az új jelszavak nem egyeznek.";
    } else {
        // Lekérdezzük az aktuális admin adatait
        $felhasznalo = $_SESSION['belepett'];
        $sql = "SELECT * FROM admin WHERE fnev = ?";
        $admin = $db->executeSelectQuery($sql, [$felhasznalo], "s");

        if ($admin && password_verify($regiJelszo, $admin[0]['passwd'])) {
            // Jelszó frissítése
            $ujHash = password_hash($ujJelszo, PASSWORD_DEFAULT);
            $updateSql = "UPDATE admin SET passwd = ? WHERE fnev = ?";
            $db->executeQuery($updateSql, [$ujHash, $felhasznalo], "ss");
            $uzenet = "A jelszavad sikeresen frissítve lett.";
        } else {
            $uzenet = "A régi jelszó hibás.";
        }
    }
}
?>

<h3>Jelszó módosítása</h3>
<p>Bejelentkezett admin: <strong><?= htmlspecialchars($_SESSION['belepett']) ?></strong></p>

<?php if ($uzenet): ?>
    <p><strong><?= htmlspecialchars($uzenet) ?></strong></p>
<?php endif; ?>

<div class="jelszo-modosito">
    <h3>Jelszó módosítása</h3>
    <p>Bejelentkezett admin: <strong><?= htmlspecialchars($_SESSION['belepett']) ?></strong></p>

    <?php if ($uzenet): ?>
        <p><strong><?= htmlspecialchars($uzenet) ?></strong></p>
    <?php endif; ?>

    <form method="POST">
        <label for="regi_jelszo">Régi jelszó:</label>
        <input type="password" name="regi_jelszo" required><br>

        <label for="uj_jelszo">Új jelszó:</label>
        <input type="password" name="uj_jelszo" required><br>

        <label for="uj_jelszo2">Új jelszó újra:</label>
        <input type="password" name="uj_jelszo2" required><br>

        <button type="submit">Jelszó frissítése</button>
    </form>
</div>
