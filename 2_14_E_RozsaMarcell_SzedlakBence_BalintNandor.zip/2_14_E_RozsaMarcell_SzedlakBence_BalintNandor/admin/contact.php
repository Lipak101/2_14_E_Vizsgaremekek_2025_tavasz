<?php
//session_start();
if (!isset($_SESSION['belepett'])) {
    header("Location: index.php");
    exit();
}

include('includes/dbvezerlo.php');

$dbvez = new DBVezerlo();

// Frissítés feldolgozása
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cim = $_POST['cim'];
    $email = $_POST['email'];
    $tel = $_POST['tel'];

    $query = "UPDATE contact SET cim = ?, Email = ?, tel = ? WHERE id = 1";
    $params = [$cim, $email, $tel];
    $dbvez->executeQuery($query, $params, "sss");

    echo "<p class='success'>Kapcsolati adatok frissítve!</p>";
}

// Aktuális adatok lekérdezése
$query = "SELECT * FROM contact WHERE id = 1";
$eredmeny = $dbvez->executeSelectQuery($query, []);
if (!empty($eredmeny)) {
    $contact = $eredmeny[0];
    $cim = $contact['cim'];
    $email = $contact['Email'];
    $tel = $contact['tel'];
} else {
    $cim = $email = $tel = '';
}
?>

<section class="contact-form">
    <h2>Kapcsolati adatok szerkesztése</h2>
    <form method="POST">
        <div class="form-group">
            <label for="cim">Cím:</label>
            <input type="text" name="cim" value="<?php echo htmlspecialchars($cim); ?>" required>
        </div>

        <div class="form-group">
            <label for="email">E-mail:</label>
            <input type="email" name="email"
                   value="<?php echo htmlspecialchars($email); ?>"
                   pattern="^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
                   title="Pl.: info@valami.hu"
                   required>
        </div>

        <div class="form-group">
            <label for="tel">Telefonszám:</label>
            <input type="tel" name="tel"
                   value="<?php echo htmlspecialchars($tel); ?>"
                   pattern="^\+\d{2} \d{2} \d{3} \d{2} \d{2}$"
                   title="Pl.: +36 20 123 45 67"
                   required>
        </div>

        <button type="submit">Mentés</button>
    </form>
</section>

</body>
</html>
