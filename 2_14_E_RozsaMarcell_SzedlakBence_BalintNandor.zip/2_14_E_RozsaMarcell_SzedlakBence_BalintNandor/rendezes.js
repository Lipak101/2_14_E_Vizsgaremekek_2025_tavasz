document.addEventListener('DOMContentLoaded', function () {
    const rendezSelect = document.getElementById('rendezes');
    rendezSelect.addEventListener('change', function () {
        const ertek = this.value;
        if (ertek === 'ar_novekvo') {
            rendezAutok(true, false);
        } else if (ertek === 'ar_csokkeno') {
            rendezAutok(true, true);
        } else if (ertek === 'nev_az') {
            rendezAutok(false, false);
        } else if (ertek === 'nev_za') {
            rendezAutok(false, true);
        }
    });
  
    function rendezAutok(arSzerint, csokkeno) {
        const autok = Array.from(document.querySelectorAll('.auto'));
  
        autok.sort((a, b) => {
            let ertekA, ertekB;
  
            if (arSzerint) {
                ertekA = parseInt(a.querySelector('.ar').textContent.replace(/\D/g, ''));
                ertekB = parseInt(b.querySelector('.ar').textContent.replace(/\D/g, ''));
            } else {
                ertekA = a.querySelector('h3').textContent.toLowerCase();
                ertekB = b.querySelector('h3').textContent.toLowerCase();
            }
  
            if (ertekA < ertekB) return csokkeno ? 1 : -1;
            if (ertekA > ertekB) return csokkeno ? -1 : 1;
            return 0;
        });
  
        const container = document.querySelector('.autok-halo');
        autok.forEach(auto => container.appendChild(auto));
    }
  });