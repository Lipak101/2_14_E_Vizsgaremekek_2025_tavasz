<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nev    = $kapcsolat->real_escape_string($_POST['nev']    ?? '');
    $email  = $kapcsolat->real_escape_string($_POST['email']  ?? '');
    $uzenet = $kapcsolat->real_escape_string($_POST['uzenet'] ?? '');

    if (!$nev || !$email || !$uzenet) {
        http_response_code(400);
        echo json_encode(['error' => 'Hiányzó adatok']);
        exit;
    }

    $stmt = $kapcsolat->prepare(
      "INSERT INTO kapcsolatok (nev, email, uzenet) VALUES (?, ?, ?)"
    );
    $stmt->bind_param("sss", $nev, $email, $uzenet);
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Hiba az adatbázisban']);
    }
    $stmt->close();
}
?>
