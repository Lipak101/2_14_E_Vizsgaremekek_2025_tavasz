window.kategoriaMegjelenites = function (kategoriaId) {
  const autokDiv = document.getElementById("autok-halo");
  if (!autokDiv) return;

  const autok = autokDiv.querySelectorAll(".auto");

  if (kategoriaId === "osszes") {
      autok.forEach(auto => auto.style.display = "block");
  } else {
      autok.forEach(auto => {
          if (auto.classList.contains(kategoriaId)) {
              auto.style.display = "block";
          } else {
              auto.style.display = "none";
          }
      });
  }
};


  // Kosár inicializálása sessionStorage-ból
  let kosar = JSON.parse(sessionStorage.getItem("kosar")) || [];
  let felhasznaloNev = sessionStorage.getItem("felhasznaloNev") || "";
  let felhasznaloEmail = sessionStorage.getItem("felhasznaloEmail") || "";

  function mentKosar() {
      sessionStorage.setItem("kosar", JSON.stringify(kosar));
  }

  function frissitKosar() {
      const kosarLista = document.getElementById("kosar-lista");
      if (!kosarLista) return;
  
      kosarLista.innerHTML = "";
  
      if (kosar.length === 0) {
          kosarLista.innerHTML = "<li>A kosár üres.</li>";
      } else {
          kosar.forEach((item, index) => {
              let li = document.createElement("li");
              li.innerHTML = `
${item.nev} - ${item.ar} Ft/nap
<input type="number" class="nap-valto" data-index="${index}" value="${item.napok}" min="1" max="30" style="width: 60px; margin-left: 10px;">
<button class="torles-gomb" data-index="${index}" style="border:none; background:none; cursor:pointer; font-size:16px; color:red;">❌</button>`;

              kosarLista.appendChild(li);
          });
      }
  
      // Frissítés végösszeggel
      let vegosszeg = 0;
      kosar.forEach(item => {
          vegosszeg += item.ar * item.napok;
      });
      const osszegElem = document.getElementById("osszegErtek");
      if (osszegElem) {
          osszegElem.textContent = new Intl.NumberFormat('hu-HU').format(vegosszeg) + " Ft";
      }
  
      let hiddenField = document.getElementById("foglalas-autonev-hidden");
      if (hiddenField) {
          hiddenField.value = JSON.stringify(kosar);
      }
  
      document.querySelectorAll(".torles-gomb").forEach(button => {
          button.addEventListener("click", function () {
              let index = this.getAttribute("data-index");
              kosar.splice(index, 1);
              mentKosar();
              frissitKosar();
          });
      });
      // Napok változtatása külön-külön
document.querySelectorAll(".nap-valto").forEach(input => {
  input.addEventListener("input", function () {
      const index = parseInt(this.getAttribute("data-index"));
      const ujNapok = parseInt(this.value) || 1;
      kosar[index].napok = ujNapok;
      mentKosar();
      frissitKosar(); // újraszámol mindent
  });
});

  }

  

  window.hozzaadKosarhoz = function (autoNev, ar) {
      let napok = 1;
  
      document.querySelectorAll(".auto").forEach(auto => {
          const nev = auto.querySelector("h3")?.textContent?.trim();
          if (nev === autoNev) {
              const napInput = auto.querySelector(".napok-szama");
              if (napInput) napok = parseInt(napInput.value) || 1;
          }
      });
  
      fetch("kosar_hozaadasa.php", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: "autonev=" + encodeURIComponent(autoNev) + "&napok=" + encodeURIComponent(napok)
      })
      .then(res => res.json())
      .then(data => {
          if (data.siker && data.kosar) {
              sessionStorage.setItem("kosar", JSON.stringify(data.kosar));
              window.dispatchEvent(new Event("kosarFrissult"));
          }
      });
  };
  
  // garantált kosár frissítés esemény alapján
  document.addEventListener("DOMContentLoaded", () => {
      window.addEventListener("kosarFrissult", () => {
          frissitKosar();
          frissitKosarat();
      });
  });
      frissitKosarat();
 
  
  
  
// Frissítés a DOM-ban, ha létezik az adott ID
// const osszegElem = document.getElementById("osszegErtek");
// if (osszegElem) {
//   osszegElem.textContent = new Intl.NumberFormat('hu-HU').format(vegosszeg) + " Ft";
// }


  // Szürkézés és felirat a foglalt autóknál
  const foglaltAutok = window.foglaltAutok || {};
  document.querySelectorAll(".auto").forEach(autoDiv => {
      let nevElem = autoDiv.querySelector("h3");
      if (!nevElem) return;

      let nev = nevElem.textContent.trim();
      if (foglaltAutok[nev]) {
          autoDiv.style.opacity = 0.4;
          let gomb = autoDiv.querySelector("button");
          if (gomb) {
              gomb.disabled = true;
              gomb.textContent = "Már lefoglalva";
              gomb.style.cursor = "not-allowed";
          }

          let kozlemeny = document.createElement("p");
          kozlemeny.style.color = "#666";
          kozlemeny.style.fontSize = "0.9em";
          kozlemeny.textContent = `Eddig lefoglalva: ${foglaltAutok[nev]}`;
          autoDiv.appendChild(kozlemeny);
      }
  });

  // 🗓️ Foglalás dátum mező korlátozása: csak holnaptól
  document.addEventListener("DOMContentLoaded", function () {
      const datumMezo = document.getElementById("foglalas-datum");
      if (datumMezo) {
        const holnap = new Date();
        holnap.setDate(holnap.getDate() + 1);
        const ev = holnap.getFullYear();
        const honap = String(holnap.getMonth() + 1).padStart(2, '0');
        const nap = String(holnap.getDate()).padStart(2, '0');
        const holnapiDatum = `${ev}-${honap}-${nap}`;
        datumMezo.setAttribute("min", holnapiDatum);
      }
    });
    

  // Napok számának figyelése – frissítés kosárban
  const foglalasIdoInput = document.getElementById("foglalas-ido");
  if (foglalasIdoInput) {
      foglalasIdoInput.addEventListener("input", function () {
          let ujNapok = parseInt(this.value) || 1;
          kosar.forEach(auto => auto.napok = ujNapok);
          mentKosar();
          frissitKosar();
      });
  }

  frissitKosar();

  /* MODÁLIS ABLAKOK KEZELÉSE */
  document.addEventListener("DOMContentLoaded", () => {
      const overlay    = document.getElementById("overlay");
      const regGomb    = document.getElementById("regisztracio-gomb");
      const belepGomb  = document.getElementById("belepes-gomb");
      const regModal   = document.getElementById("regisztracio");
      const belepModal = document.getElementById("belepes");
    
      // DEBUG: így látjuk, hogy ez a script tényleg betöltődött-e
      console.log(">>> modal script betöltve", {overlay, regGomb, belepGomb});
    
      if (regGomb) {
        regGomb.addEventListener("click", e => {
          e.preventDefault();
          console.log("Regisztráció gomb: kattintva");
          regModal.style.display   = "block";
          belepModal.style.display = "none";
          overlay.style.display    = "block";
        });
      }
    
      if (belepGomb) {
        belepGomb.addEventListener("click", e => {
          e.preventDefault();
          console.log("Bejelentkezés gomb: kattintva");
          belepModal.style.display = "block";
          regModal.style.display   = "none";
          overlay.style.display    = "block";
        });
      }
    
      if (overlay) {
        overlay.addEventListener("click", () => {
          console.log("Overlay kattintva – bezárjuk");
          regModal.style.display   = "none";
          belepModal.style.display = "none";
          overlay.style.display    = "none";
        });
      }
    });
    
    
  //  function zarasFelulet() {
  //      if (regisztracioElem) regisztracioElem.style.display = "none";
  //      if (belepesElem) belepesElem.style.display = "none";
  //      if (overlay) overlay.style.display = "none";
  // }

  window.velemenyHozzaadasa = function () {
      const autoNev = document.getElementById("velemeny-autonev").value.trim();
      const szoveg  = document.getElementById("velemeny-szoveg").value.trim();
      if (!autoNev || !szoveg) {
        alert("Kérjük, tölts ki minden mezőt!");
        return;
      }
    
      fetch("velemeny_hozzaadasa.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `autonev=${encodeURIComponent(autoNev)}&szoveg=${encodeURIComponent(szoveg)}`
      })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          alert("Köszönjük a véleményed!");
          document.getElementById("velemeny-urlap").reset();
        } else {
          alert("Hiba: " + (data.error || "Ismeretlen hiba"));
        }
      })
      .catch(err => {
        console.error("Vélemény küldés hiba:", err);
        alert("Nem sikerült kapcsolatot létesíteni a szerverrel.");
      });
    };
    
    
    window.kapcsolatHozzaadasa = function () {
      const nev    = document.getElementById("kapcsolat-nev").value.trim();
      const email  = document.getElementById("kapcsolat-email").value.trim();
      const uzenet = document.getElementById("kapcsolat-uzenet").value.trim();
      if (!nev || !email || !uzenet) {
        alert("Kérjük, tölts ki minden mezőt!");
        return;
      }
    
      fetch("kapcsolat_hozzaadasa.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `nev=${encodeURIComponent(nev)}&email=${encodeURIComponent(email)}&uzenet=${encodeURIComponent(uzenet)}`
      })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          alert(`Köszönjük, ${nev}! Üzeneted rögzítettük.`);
          document.getElementById("kapcsolat-urlap").reset();
        } else {
          alert("Hiba: " + (data.error || "Ismeretlen hiba"));
        }
      })
      .catch(() => alert("Nem sikerült kapcsolatot létesíteni a szerverrel."));
    };
    
// Lefut amikor betölt az oldal
window.addEventListener("DOMContentLoaded", () => {
  document.addEventListener("DOMContentLoaded", function () {
      const datumMezo = document.getElementById("foglalas-datum");
      if (datumMezo) {
          const holnap = new Date();
          holnap.setDate(holnap.getDate() + 1);
  
          const ev = holnap.getFullYear();
          const honap = String(holnap.getMonth() + 1).padStart(2, '0');
          const nap = String(holnap.getDate()).padStart(2, '0');
  
          const holnapiDatum = `${ev}-${honap}-${nap}`;
          datumMezo.min = holnapiDatum;
          datumMezo.value = holnapiDatum; // így alapból is holnap lesz kiválasztva
      }
  });
  


});
let allAutok = [];
window.addEventListener("DOMContentLoaded", () => {
const kontener = document.getElementById("autok-halo");
if (kontener) allAutok = Array.from(kontener.querySelectorAll(".auto"));
frissitAutoLista();
});

function frissitAutoLista() {
const kontener        = document.getElementById("autok-halo");
if (!kontener) return;

const kereso          = document.getElementById("auto-kereso")?.value.trim().toLowerCase() || "";
const rendezes        = document.getElementById("rendezes")?.value;
const csakElerheto    = document.getElementById("csak-elerheto")?.checked;
const kategoria       = document.getElementById("kategoriak-select")?.value || "osszes";

// **Ez már MINDEN eredeti kártya**
const autok = allAutok;

  // Szűrés
  const lathatoAutok = autok.filter(auto => {
    // 1) Kategória egyezés
    if (kategoria !== "osszes" && !auto.classList.contains(kategoria)) {
      return false;
    }
    // 2) Csak elérhető?
    if (csakElerheto) {
      const btn = auto.querySelector("button");
      if (btn && btn.disabled) return false;
    }
    // 3) Kereső feltétel
    const szoveg = (auto.querySelector("h3")?.textContent + " " + 
                    (auto.querySelector("p")?.textContent||""))
                   .toLowerCase();
    //if (kereso && !szoveg.includes(kereso)) return false;

    return true;
  });

  // Rendezés
  lathatoAutok.sort((a, b) => {
    if (rendezes === "nev_az") {
      return a.querySelector("h3").textContent.localeCompare(b.querySelector("h3").textContent);
    }
    if (rendezes === "nev_za") {
      return b.querySelector("h3").textContent.localeCompare(a.querySelector("h3").textContent);
    }
    if (rendezes === "ar_novekvo") {
      return parseInt(a.getAttribute("data-ar"),10) - parseInt(b.getAttribute("data-ar"),10);
    }
    if (rendezes === "ar_csokkeno") {
      return parseInt(b.getAttribute("data-ar"),10) - parseInt(a.getAttribute("data-ar"),10);
    }
    return 0;
  });

  // Újrarajzolás
  kontener.innerHTML = "";
  lathatoAutok.forEach(auto => kontener.appendChild(auto));
}




  document.querySelectorAll(".kosarba-btn").forEach(function (gomb) {
  gomb.addEventListener("click", function () {
      const autoNev = this.getAttribute("data-autonev");
      const napokInput = this.previousElementSibling;
      const napok = napokInput.value;

      fetch("kosar_hozaadasa.php", {
          method: "POST",
          headers: {
              "Content-Type": "application/x-www-form-urlencoded"
          },
          body: "autonev=" + encodeURIComponent(autoNev) + "&napok=" + encodeURIComponent(napok)
      })
      .then(data => {
          if (data.siker && data.kosar) {
              sessionStorage.setItem("kosar", JSON.stringify(data.kosar));
              kosar = data.kosar;
              setTimeout(() => {
                  frissitKosar();
                  frissitKosarat();
              }, 50);
          }
      });
      
      
      
  });
});

function frissitKosar() {
  const kosarLista = document.getElementById("kosar-lista");
  if (!kosarLista) return;

  let kosar = JSON.parse(sessionStorage.getItem("kosar"));

  if (!kosar || kosar.length === 0) {
      kosarLista.innerHTML = "<li>A kosár üres.</li>";
      document.getElementById("osszegErtek").textContent = "0 Ft";
      sessionStorage.removeItem("kosar");
      const hiddenField = document.getElementById("foglalas-autonev-hidden");
      if (hiddenField) hiddenField.value = "";
      return;
  }

  kosarLista.innerHTML = "";
  let vegosszeg = 0;
  kosar.forEach((item, index) => {
      const nev = item.autonev || item.nev;
      const ar = item.ar || 0;

      const napok = item.napok || 1;
      const osszeg = ar * napok;
      vegosszeg += osszeg;

      let li = document.createElement("li");
      li.innerHTML = `${nev} – <input type='number' min='1' value='${napok}' data-index='${index}' class='napok-modosit' style='width: 60px;'> nap – ${osszeg.toLocaleString()} Ft
      <button class="torles-gomb" data-index="${index}" style="border:none; background:none; cursor:pointer; font-size:16px; color:red;">❌</button>`;
      kosarLista.appendChild(li);
  });

  document.getElementById("osszegErtek").textContent = vegosszeg.toLocaleString() + " Ft";

  document.querySelectorAll(".torles-gomb").forEach(button => {
      button.addEventListener("click", function () {
          const index = this.getAttribute("data-index");
          kosar.splice(index, 1);
          sessionStorage.setItem("kosar", JSON.stringify(kosar));
          
          // Törlés szerver oldalon is
          fetch("torles_kosarbol.php", {
              method: "POST",
              headers: { "Content-Type": "application/x-www-form-urlencoded" },
              body: "index=" + encodeURIComponent(index)
          }).then(() => {
              frissitKosar();
              frissitKosarat();
          });
          
      });
  });

  document.querySelectorAll(".napok-modosit").forEach(input => {
      input.addEventListener("change", function () {
          const index = this.getAttribute("data-index");
          const ujNap = parseInt(this.value);
          if (ujNap > 0) {
              kosar[index].napok = ujNap;
              sessionStorage.setItem("kosar", JSON.stringify(kosar));
              frissitKosar();
              frissitKosarat();
          }
      });
  });

  const hiddenField = document.getElementById("foglalas-autonev-hidden");
  if (hiddenField) {
      hiddenField.value = JSON.stringify(kosar);
      }
}


document.getElementById("auto-kereso")?.addEventListener("input",  frissitAutoLista);
document.getElementById("rendezes")?.addEventListener("change",  frissitAutoLista);
document.getElementById("csak-elerheto")?.addEventListener("change", frissitAutoLista);
window.addEventListener("DOMContentLoaded", frissitAutoLista);


window.addEventListener('load', frissitKosarat);
window.addEventListener("DOMContentLoaded", frissitAutoLista);

document.addEventListener("DOMContentLoaded", function () {
const kapcsolatGomb  = document.getElementById("kapcsolat-gomb");
const kapcsolatModal = document.getElementById("kapcsolat");
const overlay        = document.getElementById("overlay");

if (!kapcsolatGomb || !kapcsolatModal || !overlay) return;

// “Kapcsolat” megjelenítése gombra kattintva
kapcsolatGomb.addEventListener("click", function (e) {
  e.preventDefault();
  kapcsolatModal.style.display = "block";
  overlay.style.display        = "block";
});

// Overlay-re kattintva elrejtjük a modalt
overlay.addEventListener("click", function () {
  kapcsolatModal.style.display = "none";
  overlay.style.display        = "none";
});
});





