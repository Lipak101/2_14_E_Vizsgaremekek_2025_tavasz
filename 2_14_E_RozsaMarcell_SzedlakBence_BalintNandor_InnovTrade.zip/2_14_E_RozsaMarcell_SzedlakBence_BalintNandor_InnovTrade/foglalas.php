<?php
// ⚠️ Hibák megjelenítése fejlesztéshez
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // 1) Próbáljuk először a POST-ból dekódolni a JSON kosarat
    $autokLista = [];
    if (!empty($_POST['autonev'])) {
        $decoded = json_decode($_POST['autonev'], true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $autokLista = $decoded;
        }
    }

    // 3) Ha még mindig üres, hibázunk
    if (empty($autokLista)) {
        echo "<h3 style='color: red; text-align: center;'>❌ A kosarad üres, nincs mit lefoglalni!</h3>";
        exit;
    }

    // Foglalás dátum és össznapok
    $datum = $_POST['datum'] ?? '';
    // új foglalásnál össznapok számítása (ez a régi, hibás blokk)
    $ido = 0;
    foreach ($_SESSION['kosar'] as $auto) {
        $ido += (int)($auto['napok'] ?? 1);
    }


    // Felhasználó adatok
    $nev   = $_SESSION['felhasznalo'] ?? "Nincs megadva";
    $email = $_SESSION['email']      ?? "Nincs megadva";

    // Alapvalidáció
    if (empty($datum) || $ido <= 0) {
        echo "<h3 style='color: red; text-align: center;'>❌ Hiányzó adatok a foglaláshoz!</h3>";
        exit;
    }
    $maiDatum       = new DateTime();
    $foglalasiDatum = DateTime::createFromFormat('Y-m-d', $datum);
    if (!$foglalasiDatum || $foglalasiDatum <= $maiDatum) {
        echo "<h3 style='color: red; text-align: center;'>❌ Csak a mai nap utáni napra lehet foglalni!</h3>";
        exit;
    }

    // Autóárak lekérése
    $autoArak = [];
    $eredmeny = $kapcsolat->query("SELECT nev, ar FROM autok");
    if ($eredmeny) {
        while ($sor = $eredmeny->fetch_assoc()) {
            $autoArak[$sor['nev']] = (int)$sor['ar'];
        }
    }

    // Már létező foglalások lekérése dátumütközéshez
    $foglalasok = [];
    $rs = $kapcsolat->query("
        SELECT f.datum, fa.auto_nev 
        FROM foglalasok f 
        JOIN foglalas_autok fa ON f.id = fa.foglalas_id
    ");
    if ($rs) {
        while ($sor = $rs->fetch_assoc()) {
            $foglalasok[$sor['auto_nev']][] = $sor['datum'];
        }
    }

    // Számla tételek előkészítése
    $teljesOsszeg   = 0;
    $szamlaTetelek  = [];

    foreach ($autokLista as $auto) {
        // Autó neve és napok
        $autoNev = $auto['autonev'] ?? $auto['nev'] ?? '';
        $napok   = isset($auto['napok']) ? (int)$auto['napok'] : 1;

        // Dátumütközés ellenőrzés
        if (isset($foglalasok[$autoNev]) && in_array($datum, $foglalasok[$autoNev], true)) {
            echo "<h3 style='color: red; text-align: center;'>❌ A(z) {$autoNev} már le van foglalva erre a napra!</h3>";
            exit;
        }

        // Ár ellenőrzés és tételépítés
        if (!isset($autoArak[$autoNev])) {
            echo "<h3 style='color: red; text-align: center;'>❌ Ár nem található ehhez az autóhoz: {$autoNev}</h3>";
            exit;
        }
        $netar  = $autoArak[$autoNev];
        $osszeg = $netar * $napok;
        $teljesOsszeg += $osszeg;

        $szamlaTetelek[] = [
            'termek' => $autoNev,
            'darab'  => $napok,
            'netar'  => $netar,
            'osszeg' => $osszeg,
        ];
    } // <-- itt zárul a foreach

    // Számla adatok session-be
    $_SESSION['szamla_adatok'] = [
        'felhasznalo_nev'   => $nev,
        'felhasznalo_email' => $email,
        'datum'             => $datum,
        'szamla_sorszam'    => "INV" . date("Ymd") . rand(1000, 9999),
        'tetel_lista'       => $szamlaTetelek,
        'teljes_osszeg'     => $teljesOsszeg,
    ];
    // Szükséges session-értékek megőrzése
    $_SESSION['email']        = $email;
    $_SESSION['felhasznalo']  = $nev;

    // Felhasználó ID lekérése / beszúrása
    $sql     = "SELECT id FROM felhasznalok WHERE email = '$email'";
    $eredm   = $kapcsolat->query($sql);
    if ($eredm && $eredm->num_rows > 0) {
        $sor  = $eredm->fetch_assoc();
        $felhasznalo_id = $sor['id'];
    } else {
        echo "<h3 style='color: red; text-align: center;'>❌ Felhasználó nem található!</h3>";
        exit;
    }

    // Foglalás mentése
    $kapcsolat->query("
        INSERT INTO foglalasok (felhasznalo_id, datum, ido, osszeg) 
        VALUES ('$felhasznalo_id', '$datum', '$ido', '$teljesOsszeg')
    ");
    $foglalas_id = $kapcsolat->insert_id;

    // Kapcsoló tábla mentése
    foreach ($autokLista as $auto) {
        $autoNev = $auto['autonev'] ?? $auto['nev'] ?? '';
        $stmt = $kapcsolat->prepare("
            INSERT INTO foglalas_autok (foglalas_id, auto_nev) 
            VALUES (?, ?)
        ");
        $stmt->bind_param("is", $foglalas_id, $autoNev);
        $stmt->execute();
        $stmt->close();
    }

    $_SESSION['szamla_elkeszult'] = true;

    // PDF-generálás és email küldés
    require_once 'pdf/pdf_generalas.php';
    require_once 'szamla_kuldes.php';

    // Kosár ürítése és átirányítás
    unset($_SESSION['kosar']);
    header("Location: foglalas_koszonjuk.php");
    exit();
}
?>
