function showYearlyRevenue() {
    var yearlyRevenueDiv = document.getElementById("yearly-revenue");
    if (yearlyRevenueDiv.style.display === "none") {
        yearlyRevenueDiv.style.display = "block";
    } else {
        yearlyRevenueDiv.style.display = "none";
    }
}
