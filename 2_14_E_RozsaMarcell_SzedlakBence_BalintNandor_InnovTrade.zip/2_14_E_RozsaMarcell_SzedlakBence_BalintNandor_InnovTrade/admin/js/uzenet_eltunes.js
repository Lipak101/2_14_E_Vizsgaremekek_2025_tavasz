// uzenet_eltunes.js

document.addEventListener('DOMContentLoaded', function () {
    const uzenetElem = document.getElementById('frissites-uzenet');
    if (uzenetElem) {
        setTimeout(function () {
            uzenetElem.style.transition = 'opacity 1s ease';
            uzenetElem.style.opacity = '0';
            setTimeout(() => {
                uzenetElem.style.display = 'none';
            }, 1000); // Várunk még 1 másodpercet, hogy a fade-out lemenjen
        }, 20000); // 20 másodperc után indul az eltűnés
    }
});
