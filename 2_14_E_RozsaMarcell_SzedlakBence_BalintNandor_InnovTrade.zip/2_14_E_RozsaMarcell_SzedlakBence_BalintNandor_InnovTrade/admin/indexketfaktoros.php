<?php
session_start();
include('./includes/dbvezerlo.php');

if (isset($_POST['belep'])) {
    $fnev = $_POST['fnev'];
    $jelszo = $_POST['passwd'];

    $dbvez = new DBVezerlo();

    // Lekérdezzük a felhasználót
    $query = "SELECT fnev, passwd, email FROM admin WHERE fnev = ?";
    $eredmeny = $dbvez->executeSelectQuery($query, [$fnev], "s");

    if (!empty($eredmeny)) {
        $hashed_password = $eredmeny[0]['passwd'];
        $email = $eredmeny[0]['email']; // E-mail cím a kód küldéshez

        // Jelszó ellenőrzés
        if (password_verify($jelszo, $hashed_password)) {
            // 6 számjegyű kód generálása
            $kod = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);

            // Mentjük ideiglenesen a kódot és felhasználót
            $_SESSION['2fa_code'] = $kod;
            $_SESSION['2fa_email'] = $email;
            $_SESSION['2fa_fnev'] = $fnev;

            // E-mail küldés
            $targy = "Admin belépés megerősítő kód";
            $uzenet = "A belépés megerősítéséhez használd az alábbi kódot:\n\n$kod\n\nA kód 10 percig érvényes.";
            $fejlec = "From: noreply@caradmin.hu";

            if (mail($email, $targy, $uzenet, $fejlec)) {
                header("Location: megerosit.php");
                exit();
            } else {
                echo "<script>alert('Nem sikerült e-mailt küldeni a hitelesítő kóddal.');</script>";
            }
        } else {
            echo "<script>alert('Hibás jelszó');</script>";
        }
    } else {
        echo "<script>alert('Hibás felhasználónév');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Belépés</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h1>Belépés az adminfelületre</h1>
    <form method="post">
        <label for="fnev">Felhasználónév</label>
        <input type="text" name="fnev" placeholder="Felhasználónév" required>

        <label for="passwd">Jelszó</label>
        <input type="password" name="passwd" placeholder="Jelszó" required>

        <button type="submit" name="belep">BELÉPÉS</button>
    </form>

    <p><a href="./main/index.php">Vissza a főoldalra</a></p>
</body>
</html>
