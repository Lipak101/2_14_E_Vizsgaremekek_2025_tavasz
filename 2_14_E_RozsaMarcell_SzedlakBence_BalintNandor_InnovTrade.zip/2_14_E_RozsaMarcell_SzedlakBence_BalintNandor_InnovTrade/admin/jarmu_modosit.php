<?php
if (!isset($_SESSION['belepett'])) {
    header("Location: index.php");
    exit();
}

include('includes/dbvezerlo.php');
$dbvez = new DBVezerlo();

$frissitett_jarmu = null;

// Feldolgozás, ha elküldték a módosító űrlapot
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['jarmu_id'], $_POST['uj_ar'])) {
    $jarmu_id = intval($_POST['jarmu_id']);
    $uj_ar = floatval($_POST['uj_ar']);

    $update_query = "UPDATE jarmuvek SET ar = ? WHERE id = ?";
    $dbvez->executeQuery($update_query, [$uj_ar, $jarmu_id], "di");

    // Lekérjük a módosított jármű nevét
    $result = $dbvez->executeSelectQuery("SELECT marka FROM jarmuvek WHERE id = ?", [$jarmu_id], "i");
    if (!empty($result)) {
        $frissitett_jarmu = $result[0]['marka'];
    }
}

// Lekérjük az összes járművet
$jarmuvek = $dbvez->executeSelectQuery("SELECT id, marka, evjarat, ar FROM jarmuvek", []);
?>

<?php if ($frissitett_jarmu): ?>
    <div id="frissites-uzenet" style="color: green; font-weight: bold; padding: 10px; background: #e0ffe0; border: 1px solid #70db70; margin-bottom: 10px;">
        A(z) <strong><?= htmlspecialchars($frissitett_jarmu) ?></strong> árát sikeresen frissítettük!
    </div>
<?php endif; ?>

<section class="jarmu-modosit">
    <h3>Jármű ár módosítása</h3>
    <form method="POST">
        <div class="form-group">
            <label for="jarmu_id">Válassz járművet:</label>
            <select name="jarmu_id" required>
                <?php
                foreach ($jarmuvek as $jarmu) {
                    echo "<option value='" . $jarmu['id'] . "'>" .
                        htmlspecialchars($jarmu['marka']) . " (" . $jarmu['evjarat'] . ") - " .
                        number_format($jarmu['ar'], 0, ',', ' ') . " Ft</option>";
                }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label for="uj_ar">Új ár (Ft):</label>
            <input type="number" name="uj_ar" step="0.01" required>
        </div>

        <button type="submit">Mentés</button>
    </form>
</section>

<!-- JavaScript meghívása -->
<script src="js/uzenet_eltunes.js"></script>
