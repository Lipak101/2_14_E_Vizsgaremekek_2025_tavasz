<?php
//session_start();
if (!isset($_SESSION['belepett'])) {
    header("Location: index.php");
    exit();
}

include('includes/dbvezerlo.php');
$db = new DBVezerlo();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fnev = $_POST['fnev'] ?? '';
    $passwd = $_POST['passwd'] ?? '';

    if (empty($fnev) || empty($passwd)) {
        echo "Felhasználónév és jelszó megadása kötelező!";
        exit();
    }

    // Jelszó titkosítása
    $hashedPasswd = password_hash($passwd, PASSWORD_DEFAULT);

    // Új adminisztrátor hozzáadása
    $query = "INSERT INTO admin (fnev, passwd) VALUES (?, ?)";
    $params = [$fnev, $hashedPasswd];
    $types = "ss";

    if ($db->executeQuery($query, $params, $types)) {
        echo "Új adminisztrátor sikeresen hozzáadva!";
    } else {
        echo "Hiba történt az adminisztrátor hozzáadásakor.";
    }
}
?>

<form method="POST">
    <label for="fnev">Felhasználónév:</label>
    <input type="text" name="fnev" required>

    <label for="passwd">Jelszó:</label>
    <input type="password" name="passwd" required>

    <button type="submit">Adminisztrátor hozzáadása</button>
</form>
