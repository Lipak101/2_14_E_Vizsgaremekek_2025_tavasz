<?php
if (!isset($_SESSION['belepett'])) {
    header("Location: index.php");
    exit();
}

include('includes/dbvezerlo.php');
$db = new DBVezerlo();

function jelszoEros($jelszo) {
    return preg_match('/^(?=.*[A-Za-z])(?=.*\d)(?=.*[\W_]).{8,}$/', $jelszo);
}

$uzenet = "";
$uzenetTipus = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $regiJelszo = $_POST['regi_jelszo'] ?? '';
    $ujJelszo = $_POST['uj_jelszo'] ?? '';
    $ujJelszo2 = $_POST['uj_jelszo2'] ?? '';

    if ($ujJelszo !== $ujJelszo2) {
        $uzenet = "Az új jelszavak nem egyeznek.";
        $uzenetTipus = "alert";
    } elseif (!jelszoEros($ujJelszo)) {
        $uzenet = "Az új jelszónak legalább 8 karakter hosszúnak kell lennie, tartalmaznia kell betűt, számot és speciális karaktert.";
        $uzenetTipus = "alert";
    } else {
        $felhasznalo = $_SESSION['belepett'];
        $sql = "SELECT * FROM admin WHERE fnev = ?";
        $admin = $db->executeSelectQuery($sql, [$felhasznalo], "s");

        if ($admin && password_verify($regiJelszo, $admin[0]['passwd'])) {
            $ujHash = password_hash($ujJelszo, PASSWORD_DEFAULT);
            $updateSql = "UPDATE admin SET passwd = ? WHERE fnev = ?";
            $db->executeQuery($updateSql, [$ujHash, $felhasznalo], "ss");

            $uzenet = "A jelszavad sikeresen frissítve lett.";
            $uzenetTipus = "success-msg";
        } else {
            $uzenet = "A régi jelszó hibás.";
            $uzenetTipus = "alert";
        }
    }
}
?>

<div class="jelszo-modosito" style="width: 50%; margin: 0 auto; padding: 20px;">
    <h3>Jelszó módosítása</h3>
    <p>Bejelentkezett admin: <strong><?= htmlspecialchars($_SESSION['belepett']) ?></strong></p>

    <?php if ($uzenet): ?>
        <div id="valaszUzenet" class="<?= $uzenetTipus ?>"><?= htmlspecialchars($uzenet) ?></div>
        <script>
            setTimeout(() => {
                const uzi = document.getElementById('valaszUzenet');
                if (uzi) uzi.remove();
            }, 20000);
        </script>
    <?php endif; ?>

    <form method="POST">
        <label for="regi_jelszo">Régi jelszó:</label>
        <input type="password" name="regi_jelszo" required><br>

        <label for="uj_jelszo">Új jelszó:</label>
        <input type="password" name="uj_jelszo" required><br>

        <label for="uj_jelszo2">Új jelszó újra:</label>
        <input type="password" name="uj_jelszo2" required><br>

        <button type="submit">Jelszó frissítése</button>
    </form>
</div>

