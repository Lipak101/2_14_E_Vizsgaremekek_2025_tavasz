<?php
session_start();
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $autoNev = $_POST['autonev'] ?? '';
    $napok = (int)($_POST['napok'] ?? 1);

    // Árak betöltése adatbázisból
    $autoArak = [];
    $eredmeny = $kapcsolat->query("SELECT nev, ar FROM autok");
    if ($eredmeny && $eredmeny->num_rows > 0) {
        while ($sor = $eredmeny->fetch_assoc()) {
            $autoArak[$sor['nev']] = (int)$sor['ar'];
        }
    }

    if (!isset($_SESSION['kosar'])) {
        $_SESSION['kosar'] = [];
    }

    $frissitve = false;
    foreach ($_SESSION['kosar'] as &$auto) {
        if ($auto['autonev'] === $autoNev) {
            $auto['napok'] = $napok;
            $frissitve = true;
            break;
        }
    }

    if (!$frissitve) {
        $_SESSION['kosar'][] = [
            'autonev' => $autoNev,
            'napok' => $napok,
            'ar' => $autoArak[$autoNev] ?? 0
        ];
    }

    header('Content-Type: application/json');
    echo json_encode(['siker' => true, 'kosar' => $_SESSION['kosar']]);
    exit;
}
?>
