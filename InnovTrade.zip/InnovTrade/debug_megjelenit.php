<?php
$debug = file_get_contents("debug_kosar.txt");
echo "<pre>" . htmlspecialchars($debug) . "</pre>";
?>
