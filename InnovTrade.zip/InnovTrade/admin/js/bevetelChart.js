// Ez a függvény lekéri a form mezőkből a dátumokat és a checkbox állapotát,
// majd elküldi ezeket GET paraméterként a bevetel_chart.php felé.
function frissitChart() {
    const from = document.querySelector('input[name="from_date"]').value; // Kezdő dátum
    const to = document.querySelector('input[name="to_date"]').value;     // Vég dátum
    const include = document.querySelector('input[name="include_pending"]').checked; // Checkbox állapot

    // Fetch kérés JSON válasszal a szervertől
    fetch(`bevetel_chart.php?from_date=${from}&to_date=${to}&include_pending=${include}`)
        .then(res => res.json())
        .then(data => {
            // A szervertől visszakapott márkanevek és összegek kigyűjtése
            const labels = data.map(d => d.marka);       // Pl.: Audi, BMW, stb.
            const values = data.map(d => d.osszeg);      // Pl.: 3500000, 4200000, stb.

            const ctx = document.getElementById('bevetelChart').getContext('2d');

            // Ha már létezik a chart, frissítjük az adatait
            if (window.bevetelChart) {
                window.bevetelChart.data.labels = labels;
                window.bevetelChart.data.datasets[0].data = values;
                window.bevetelChart.update();
            } else {
                // Új chart létrehozása, ha még nem létezik
                window.bevetelChart = new Chart(ctx, {
                    type: 'bar', // Oszlopdiagram
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Összes bevétel (Ft)',
                            data: values,
                            backgroundColor: 'rgba(75, 192, 192, 0.5)',
                            borderColor: 'rgba(75, 192, 192, 1)',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    callback: value => value.toLocaleString('hu-HU') // Szép formázás Ft-hoz
                                }
                            }
                        }
                    }
                });
            }
        });
}

// Oldal betöltődése után történő eseménykezelés
document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('form');

    if (form) {
        // Submit esemény figyelése a formon (ha AJAX stílusban akarjuk frissíteni a grafikont)
        form.addEventListener('submit', function(e) {
            // e.preventDefault(); // Akkor használjuk, ha nem akarjuk újratölteni az oldalt
            this.submit();         // Ha mégis szeretnénk, hogy újratöltse, akkor ezt meghagyjuk
            frissitChart();        // És közben frissítjük a chartot is
        });
    }

    // Az oldal betöltődésekor is lefuttatjuk a chart frissítését
    frissitChart();
});
