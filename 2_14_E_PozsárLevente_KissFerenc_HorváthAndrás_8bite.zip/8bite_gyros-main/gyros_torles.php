<?php
session_start();
require_once "db.php";

// Csak admin törölhet
if (!isset($_SESSION['jogosultsag']) || $_SESSION['jogosultsag'] !== 'admin') {
    header("Location: index.php");
    exit();
}

// Ellenőrizzük, hogy jött-e ID
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Törlés az etlap táblából
    $sql = "DELETE FROM menu WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        // Sikeres törlés után vissza az admin felületre
        header("Location: admin_gyrosok.php?uzenet=sikeres_torles");

        exit();
    } else {
        echo "Hiba történt a törlés során: " . $stmt->error;
    }
} else {
    echo "Hiányzó ID!";
}
?>
