<?php
session_start();
require_once 'db.php';

if (!isset($_GET['rendeles_id'])) {
    die("Hiányzó rendelés azonosító.");
}

$rendeles_id = (int)$_GET['rendeles_id'];

// Rendelés adatai
$stmt = $conn->prepare("SELECT r.rendeles_idopont, f.felhasznalonev 
                        FROM rendelesek r 
                        JOIN felhasznalok f ON r.felhasznalo_id = f.id
                        WHERE r.id = ?");
$stmt->bind_param("i", $rendeles_id);
$stmt->execute();
$stmt->bind_result($datum, $vasarlo);
if (!$stmt->fetch()) {
    die("A megadott rendelés nem található.");
}
$stmt->close();

// Tételek
$stmt = $conn->prepare("SELECT m.nev, rt.mennyiseg, rt.ar
                        FROM rendeles_tetelek rt
                        JOIN menu m ON rt.menu_id = m.id
                        WHERE rt.rendeles_id = ?");
$stmt->bind_param("i", $rendeles_id);
$stmt->execute();
$stmt->bind_result($nev, $mennyiseg, $ar);

$tetel_lista = [];
$osszeg = 0;
while ($stmt->fetch()) {
    $tetel_lista[] = ['nev' => $nev, 'mennyiseg' => $mennyiseg, 'ar' => $ar];
    $osszeg += $ar;
}
$stmt->close();
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>8BITE Gyros Számla – #<?= $rendeles_id ?></title>
    <link rel="stylesheet" href="css/szamla.css">
</head>
<body>
<div class="szamlakeret">
    <h1>8BITE GYROS SZÁMLA</h1>

    <div class="szamlainfo">
        <p>Rendelés ID: #<?= $rendeles_id ?></p>
        <p>Dátum: <?= $datum ?></p>
        <p>Vásárló: <?= htmlspecialchars($vasarlo) ?></p>
    </div>

    <div class="szamlatabla">
        <table>
            <thead>
            <tr><th>Termék</th><th>Mennyiség</th><th>Ár (Ft)</th></tr>
            </thead>
            <tbody>
            <?php foreach ($tetel_lista as $tetel): ?>
                <tr>
                    <td><?= htmlspecialchars($tetel['nev']) ?></td>
                    <td><?= $tetel['mennyiseg'] ?></td>
                    <td><?= number_format($tetel['ar'], 0, '', ' ') ?> Ft</td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="szamlaosszeg">
        Összesen: <?= number_format($osszeg, 0, '', ' ') ?> Ft
    </div>

    <a href="index.php" class="button">⬅ Vissza a főoldalra</a>
</div>
</body>
</html>
