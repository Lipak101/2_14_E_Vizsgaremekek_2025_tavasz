<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>


<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/startmenu.css">
</head>
<body>
<!-- Loader -->
<div id="loader" style="display: flex;">
  <div class="win95-loader">
    <div class="win95-titlebar">Töltés</div>
    <div class="win95-content">
      <div class="loading-bar">
        <div class="bar-fill"></div>
      </div>
      <p>Betöltés...</p>
    </div>
  </div>
</div>

<!-- LOGIN popup -->
<div id="loginOverlay" class="overlay" style="display: none;">
  <div class="ablakkeret">
      <div class="fejlec">
      8BITE BEJELENTKEZÉS
      <span class="zaras" onclick="zarPopup('loginOverlay')">X</span>
    </div>
    <div class="ablakbelso">
      <img src="img/logo.png" alt="8Bite logó">
      <input type="text" id="login-felhasznalonev" placeholder="Felhasználónév" required>
      <input type="password" id="login-jelszo" placeholder="Jelszó" required>
      <button class="logreg-btn" onclick="login()">Bejelentkezés</button>
      <div id="login-hiba" style="color: red; font-weight: bold; margin-top: 10px;"></div>
    </div>
  </div>
</div>

<!-- REGISZTRÁCIÓ popup -->
<div id="registerOverlay" class="overlay" style="display: none;">
  <div class="ablakkeret">
      <div class="fejlec">
        8BITE REGISZTRÁCIÓ
        <span class="zaras" onclick="zarPopup('registerOverlay')">X</span>
      </div>    
      <div class="ablakbelso">
        <img src="img/logo.png" alt="8Bite logó">
        <input type="text" id="reg-felhasznalonev" placeholder="Felhasználónév" required>
        <input type="password" id="reg-jelszo" placeholder="Jelszó" required>
        <input type="text" id="reg-email" placeholder="Email" required>
        <button class="logreg-btn" onclick="register()">Regisztráció</button>
        <div id="reg-hiba" style="color: red; font-weight: bold; margin-top: 10px;"></div>
      </div>
  </div>
</div>

<!-- TASKBAR (TÁLCA) -->
<div class="win95-taskbar">
  <button class="start-btn" onclick="toggleStartMenu()">
    <img src="img/start.png" alt="Start">
    Start
  </button>
  <div class="taskbar-right" id="ora">00:00</div>
</div>

<!-- START MENÜ -->
<div id="startMenu" class="win95-start-menu">
  <div class="start-kosar">
    <strong>Kosár:</strong>
    <?php
    $vegosszeg = 0;
    if (!empty($_SESSION['kosar'])) {
        foreach ($_SESSION['kosar'] as $nev => $adat) {
            $db = $adat['db'] ?? 1;
            $ar = $adat['ar'] ?? 0;
            $kep = $adat['kep'] ?? 'kep';
            $sorOsszeg = $db * $ar;

            echo "<div class='tetel' style='display: flex; align-items: center; gap: 6px;'>";
            echo "<img src='{$kep}' alt='{$nev}' style='width:30px; height:30px; border:1px solid #000;'> ";
            echo "<span>{$nev} ({$db} db) – {$sorOsszeg} Ft</span>";
            echo "<a href='kosar_modosit.php?nev=" . urlencode($nev) . "&mod=csokkent'>➖</a> ";
            echo "<a href='kosar_modosit.php?nev=" . urlencode($nev) . "&mod=novel'>➕</a> ";
            echo "<a href='kosar_modosit.php?nev=" . urlencode($nev) . "&mod=torol' class='torles'>❌</a>";
            echo "</div>";

            $vegosszeg += $sorOsszeg;
        }
        echo "<div class='osszeg'>Összesen: <strong>{$vegosszeg} Ft</strong></div>";
    } else {
        echo "<div class='ures'>A kosarad üres.</div>";
    }
    ?>
  </div>

  <div class="start-title">👤 <?= $_SESSION['felhasznalonev'] ?? 'Vendég' ?></div>
  <ul> 
  <?php if (isset($_SESSION['felhasznalonev'])): ?>
    <li><a href="profil.php">🛠️ Adatmódosítás</a></li>
    <li><a href="rendeles.php">📦 Rendeléseim</a></li>
    <li><a href="index.php">🏠 Kezdőlap</a></li>
    <?php if (isset($_SESSION['jogosultsag']) && $_SESSION['jogosultsag'] === 'admin'): ?>
      <li><a href="admin.php">🧰 Admin felület</a></li>
    <?php endif; ?>
    <li><a href="logout.php">🚪 Kijelentkezés</a></li>
  <?php else: ?>
    <li><a href="javascript:void(0);" onclick="nyisdMegLogin()">🔐 Bejelentkezés</a></li>
    <li><a href="javascript:void(0);" onclick="nyisdMegRegister()">📝 Regisztráció</a></li>
  <?php endif; ?>
  </ul>
</div>

<!-- JS -->
<script>
function toggleStartMenu() {
  const menu = document.getElementById("startMenu");
  menu.style.display = (menu.style.display === "block") ? "none" : "block";
}

function updateClock() {
  const now = new Date();
  const h = String(now.getHours()).padStart(2, '0');
  const m = String(now.getMinutes()).padStart(2, '0');
  document.getElementById("ora").innerText = `${h}:${m}`;
}
setInterval(updateClock, 1000);
window.onload = updateClock;
</script>

<script>
  document.addEventListener("DOMContentLoaded", function () {
    const loader = document.getElementById('loader');
    const bar = document.querySelector('.bar-fill');
    
    loader.style.display = 'flex';
    bar.style.width = '0%';
    bar.style.animation = 'fillBar 1.0s linear forwards';

    setTimeout(() => {
      loader.style.display = 'none';
    }, 1000); // A csík beér, utána tűnik el
  });

  document.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', function (e) {
      // Csak akkor mutassa a loadert, ha nem a popup linkre kattintottak
      if (
        !link.href.includes('#') &&
        !link.getAttribute('onclick')
      ) {
        const loader = document.getElementById('loader');
        const bar = document.querySelector('.bar-fill');

        loader.style.display = 'flex';
        bar.style.width = '0%';
        bar.style.animation = 'fillBar 3.5s linear forwards';
      }
    });
  });
</script>

<script>
document.addEventListener("DOMContentLoaded", function () {
  window.nyisdMegLogin = function () {
    document.getElementById('loginOverlay').style.display = 'flex';
  }

  window.nyisdMegRegister = function () {
    document.getElementById('registerOverlay').style.display = 'flex';
  }

  // Bezárás, ha a háttérre kattintasz
  window.addEventListener('click', function (e) {
    if (e.target.classList.contains('overlay')) {
      e.target.style.display = 'none';
    }
  });
});
function zarPopup(id) {
  document.getElementById(id).style.display = 'none';
}
</script>
<script>
// login és register JS
function login() {
  const felhasznalonev = document.getElementById('login-felhasznalonev').value;
  const jelszo = document.getElementById('login-jelszo').value;
  const hibabox = document.getElementById('login-hiba');
  hibabox.innerText = ""; // előző hiba törlése

  fetch('login.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: `felhasznalonev=${felhasznalonev}&jelszo=${jelszo}`
  })
  .then(r => r.text())
  .then(valasz => {
    if (valasz.includes("sikeres")) {
      window.location.href = window.location.href;
    } else {
      hibabox.innerText = valasz;
    }
  });
}

function register() {
  const felhasznalonev = document.getElementById('reg-felhasznalonev').value;
  const jelszo = document.getElementById('reg-jelszo').value;
  const email = document.getElementById('reg-email').value;
  const hibabox = document.getElementById('reg-hiba');
  hibabox.innerText = ""; // előző hiba törlése

  fetch('register.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: `felhasznalonev=${felhasznalonev}&jelszo=${jelszo}&email=${email}`
  })
  .then(r => r.text())
  .then(valasz => {
    if (valasz.includes("sikeres")) {
      window.location.href = window.location.href;
    } else {
      hibabox.innerText = valasz;
    }
  });
}
</script>
<script>
function login() {
  const username = document.getElementById('login-felhasznalonev').value;
  const password = document.getElementById('login-jelszo').value;
  const hibaElem = document.getElementById('login-hiba');

  // Küldjük el fetch POST-tal
  fetch('login.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`
  })
  .then(res => res.json())
  .then(data => {
    if (data.siker) {
      location.reload();
    } else {
      hibaElem.textContent = data.uzenet;
    }
  })
  .catch(err => {
    console.error('Hiba a bejelentkezés során:', err);
    hibaElem.textContent = 'Valami elromlott!';
  });
}
</script>


</body>
</html>
