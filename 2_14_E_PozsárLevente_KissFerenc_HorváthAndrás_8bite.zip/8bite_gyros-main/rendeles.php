<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['felhasznalo_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_SESSION['kosar']) || empty($_SESSION['kosar'])) {
    echo "A kosarad üres!";
    exit();
}

$felhasznalo_id = $_SESSION['felhasznalo_id'];
$email = $_SESSION['email']; // fontos a számlához

// 1️⃣ Rendelés mentése (időpont automatikus)
$stmt = $conn->prepare("INSERT INTO rendelesek (felhasznalo_id) VALUES (?)");
$stmt->bind_param("i", $felhasznalo_id);
$stmt->execute();
$rendeles_id = $stmt->insert_id;
$stmt->close();

// 2️⃣ Tételek mentése – `menu_id` és `db` kulcs alapján
$stmt = $conn->prepare("INSERT INTO rendeles_tetelek (rendeles_id, menu_id, mennyiseg, ar) VALUES (?, ?, ?, ?)");
foreach ($_SESSION['kosar'] as $menu_id => $adatok) {
    $mennyiseg = isset($adatok['db']) ? (int)$adatok['db'] : 1;
    $ar = $adatok['ar'];
    $stmt->bind_param("iiid", $rendeles_id, $menu_id, $mennyiseg, $ar);
    $stmt->execute();
}
$stmt->close();

// 3️⃣ PDF számla generálás
require 'szamla_generalas.php';

// 4️⃣ Számla emailben küldése
require 'szamla_emailkuldes.php';

// 5️⃣ Kosár ürítése
unset($_SESSION['kosar']);

// 6️⃣ Átirányítás visszajelző oldalra
header("Location: rendeles_koszonjuk.php?rendeles_id=$rendeles_id");
exit();
?>
