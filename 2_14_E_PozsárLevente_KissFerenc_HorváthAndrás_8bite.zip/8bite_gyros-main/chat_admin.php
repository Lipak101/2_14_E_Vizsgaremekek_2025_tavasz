<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <title>Admin Chat – 8Bite</title>
  <link rel="stylesheet" href="css/windows95-vaporwave.css">
  <style>
    body {
      background: url('css/chathatter.png') no-repeat center center fixed;
      background-size: cover;
      font-family: 'Tahoma', sans-serif;
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .messenger-window {
      width: 700px;
      border: 2px solid #a0c4ff;
      background-color: rgba(255, 255, 255, 0.92);
      box-shadow: 5px 5px 0 #ccc;
      border-radius: 6px;
    }

    .messenger-header {
      background-color: #e0f0ff;
      padding: 8px 12px;
      font-weight: bold;
      border-bottom: 1px solid #ccc;
      color: #000080;
      border-radius: 6px 6px 0 0;
    }

    .chat-box {
      height: 400px;
      overflow-y: auto;
      padding: 12px;
      font-size: 14px;
      line-height: 1.6;
      background-color: #ffffff;
      color: #000000;
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .chat-box .uzenet {
      max-width: 80%;
      padding: 10px 14px;
      border-radius: 16px;
      display: flex;
      align-items: center;
      gap: 10px;
      word-wrap: break-word;
    }

    .chat-box .admin {
      background-color: #e0f0ff;
      align-self: flex-end;
      border: 1px solid #a0c4ff;
      color: #003366;
      flex-direction: row-reverse;
      text-align: right;
    }

    .chat-box .user {
      background-color: #f0f0f0;
      align-self: flex-start;
      border: 1px solid #ccc;
      color: #000000;
    }

    .profil {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      object-fit: cover;
    }

    .input-bar {
      display: flex;
      border-top: 1px solid #ccc;
      padding: 10px;
      background-color: #f0f0f0;
      border-radius: 0 0 6px 6px;
    }

    .input-bar input[type="text"] {
      flex: 1;
      padding: 6px;
      border: 1px solid #aaa;
      border-radius: 3px;
    }

    .input-bar button {
      margin-left: 8px;
      padding: 6px 12px;
      background-color: #cce5ff;
      border: 1px solid #888;
      cursor: pointer;
      border-radius: 3px;
    }

    .input-bar button:hover {
      background-color: #b3d7ff;
    }
  </style>
</head>
<body>
<div class="messenger-window">
  <div class="messenger-header">
    8Bite Admin Chat Panel
  </div>
  <div class="chat-box" id="chat-box">
    <!-- Üzenetek betöltése ide -->
  </div>
  <form class="input-bar" id="admin-form">
    <input type="text" name="uzenet" id="uzenet" placeholder="Írd ide a választ..." required>
    <button type="submit">Válasz</button>
  </form>
</div>

<audio id="pingSound" src="sounds/MSN NEW EMAIL SOUNDS.mp3" preload="auto"></audio>

<script>
let utolsoTartalom = "";

function frissitChat() {
  fetch('chat_lekerdez.php')
    .then(res => res.text())
    .then(data => {
      if (data !== utolsoTartalom) {
        const box = document.getElementById('chat-box');
        box.innerHTML = data;
        box.scrollTop = box.scrollHeight;

        if (utolsoTartalom !== "") {
          const hang = document.getElementById('pingSound');
          if (hang) hang.play();
        }

        utolsoTartalom = data;
      }
    });
}

document.getElementById('admin-form').addEventListener('submit', function(e) {
  e.preventDefault();
  const uzenet = document.getElementById('uzenet').value;
  fetch('chat_valasz_admin.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'uzenet=' + encodeURIComponent(uzenet)
  }).then(() => {
    document.getElementById('uzenet').value = '';
    frissitChat();
  });
});

setInterval(frissitChat, 3000);
frissitChat();
</script>
</body>
</html>