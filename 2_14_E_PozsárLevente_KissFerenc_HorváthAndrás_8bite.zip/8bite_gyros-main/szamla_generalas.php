
<?php
ob_start(); // kimenet elnyelése
require __DIR__ . '/fpdf/fpdf.php';
require_once 'db.php';

// Karakterszűrés: csak az ASCII pixel-font kompatibilis karaktereket engedjük
function pixelbarat($szoveg) {
    $engedett = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,:;-!?()[]{}@#%&+=*/\\ \'"';
    $szoveg = mb_convert_encoding($szoveg, 'ISO-8859-2', 'UTF-8');
    return preg_replace("/[^" . preg_quote($engedett, '/') . "]/", '?', $szoveg);
}

class PDF extends FPDF {
    function Header() {
        $this->AddFont('PressStart2P-Regular', '', 'PressStart2P-Regular.php');
        $this->SetFont('PressStart2P-Regular', '', 6);
        $this->Cell(0, 10, pixelbarat('8BITE GYROS SZAMLA'), 0, 1, 'C');
        $this->Ln(10);
    }
}

$pdf = new PDF();
$pdf->AddFont('PressStart2P-Regular', '', 'PressStart2P-Regular.php');
$pdf->AddPage();
$pdf->SetFont('PressStart2P-Regular', '', 6);

// Lekérjük a rendelés idejét
$stmt = $conn->prepare("SELECT rendeles_idopont FROM rendelesek WHERE id = ?");
$stmt->bind_param("i", $rendeles_id);
$stmt->execute();
$stmt->bind_result($datum);
$stmt->fetch();
$stmt->close();

// Fejléc
$pdf->Cell(0, 10, pixelbarat("Rendeles ID: $rendeles_id"), 0, 1);
$pdf->Cell(0, 10, pixelbarat("Datum: $datum"), 0, 1);
$pdf->Ln(5);

// Tábla fejléc
$pdf->Cell(80, 10, pixelbarat("Gyros neve"), 1);
$pdf->Cell(30, 10, pixelbarat("Mennyiseg"), 1);
$pdf->Cell(30, 10, pixelbarat("Ar (HUF)"), 1);
$pdf->Ln();

// Tételek lekérdezése
$stmt = $conn->prepare("
    SELECT m.nev, rt.mennyiseg, rt.ar
    FROM rendeles_tetelek rt
    JOIN menu m ON rt.menu_id = m.id
    WHERE rt.rendeles_id = ?
");
$stmt->bind_param("i", $rendeles_id);
$stmt->execute();
$stmt->bind_result($nev, $mennyiseg, $ar);

// Sorok beírása
while ($stmt->fetch()) {
    $pdf->Cell(80, 10, pixelbarat($nev), 1);
    $pdf->Cell(30, 10, $mennyiseg, 1);
    $pdf->Cell(30, 10, number_format($ar, 0, '', ' ') . ' Ft', 1);
    $pdf->Ln();
}
$stmt->close();

// Fájl mentése
$szamla_fajl = "szamlak/szamla_$rendeles_id.pdf";


$pdf->Output('F', $szamla_fajl);
ob_end_clean(); // kimenet bezárása
?>
