<?php
session_start();

if (isset($_GET['index']) && isset($_SESSION['kosar'][$_GET['index']])) {
    unset($_SESSION['kosar'][$_GET['index']]);
    // Újraindexelés, hogy ne legyenek lyukak az array-ben
    $_SESSION['kosar'] = array_values($_SESSION['kosar']);
}

header("Location: ".$_SERVER['HTTP_REFERER']);
exit;
?>