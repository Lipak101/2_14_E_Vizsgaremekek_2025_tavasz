<?php
session_start();
include 'db.php';
?>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/kezdolap.css">
    <title>8Bite</title>
</head>
<body>
    <div class="navbar">
    <a href="index.php">Kezdőlap</a>
    <a href="etlap.php">Étlap</a>
    <a href="rolunk.php">Rólunk</a>
    <a href="kapcsolat.php">Kapcsolat</a>
  </div>

    <div class="win95-window-logo">
        <div class="win95-title-logo">Logo.exe</div>
        <img class="logo_img" src="img/logo.png" alt="logo">
    </div>


<div class="win95-container"> 
  <?php if (!isset($_SESSION['felhasznalonev'])): ?>
    <a href="javascript:void(0);" class="win95-btn" onclick="nyisdMegLogin()">Bejelentkezés</a>
    <a href="javascript:void(0);" class="win95-btn" onclick="nyisdMegRegister()">Regisztráció</a>
  <?php endif; ?>
</div>

    <div class="hero">
        <h1>Friss, finom, gyors!</h1>
        <p>Kóstold meg a legjobb gyrosainkat, válassz egyet street food kínálatunkból!</p>
    </div>

    <section id="velemenyek" class="velemenyek-container win95-window">
    <div class="win95-title">Vendégeink véleménye</div>

    <?php if (isset($_SESSION['felhasznalo_id'])): ?>
        <form action="velemeny_kuld.php" method="post" class="velemeny-form">
        <textarea name="velemeny" placeholder="Írd meg a véleményed..." required></textarea>
        <label>Értékelés:
        <div class="star-rating">
            <input type="radio" name="csillagok" value="5" id="csillag5"><label for="csillag5">★</label>
            <input type="radio" name="csillagok" value="4" id="csillag4"><label for="csillag4">★</label>
            <input type="radio" name="csillagok" value="3" id="csillag3"><label for="csillag3">★</label>
            <input type="radio" name="csillagok" value="2" id="csillag2"><label for="csillag2">★</label>
            <input type="radio" name="csillagok" value="1" id="csillag1"><label for="csillag1">★</label>
        </div>
       </label>
        <button type="submit">Küldés</button>
    </form>
    <?php else: ?>
    <p class="login-prompt">Kérlek jelentkezz be, hogy véleményt írhass!</p>
    <?php endif; ?>

    <div class="velemeny-lista">
    <?php
    $result = $conn->query("SELECT * FROM velemenyek ORDER BY datum DESC");
    while ($row = $result->fetch_assoc()):
    ?>
    <div class="velemeny-kartya">
        <strong><?= htmlspecialchars($row['felhasznalonev']) ?></strong>
        <div class="csillagok"><?= str_repeat('★', (int)$row['csillagok']) ?></div>
        <p><?= nl2br(htmlspecialchars($row['velemeny_szoveg'])) ?></p>
    </div>
    <?php endwhile; ?>
    </div>
</section>

<?php include 'startmenu.php'; ?>
</body>
</html>