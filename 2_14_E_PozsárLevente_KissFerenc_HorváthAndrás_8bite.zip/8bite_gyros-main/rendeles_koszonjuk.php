<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Rendelés leadva</title>
    <link rel="stylesheet" href="css/szamla_koszonjuk.css">
</head>
<body>
    <div class="ablak">
        <h1>✅ Köszönjük rendelésed!</h1>
        <p>A számlát elküldtük az e-mail címedre.</p>

        <?php if (isset($_GET['rendeles_id'])): ?>
            <a href="szamla_elonezet.php?rendeles_id=<?= $_GET['rendeles_id'] ?>" class="button">📄 Számla megtekintése</a><br><br>
        <?php endif; ?>

        <a href="index.php" class="button">⬅ Vissza a főoldalra</a>
    </div>
</body>
</html>
