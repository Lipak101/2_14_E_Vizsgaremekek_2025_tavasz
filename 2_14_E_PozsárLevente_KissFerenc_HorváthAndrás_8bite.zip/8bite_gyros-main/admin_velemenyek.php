<?php
session_start();
require_once "db.php"; // adatbázis kapcsolat

// Jogosultság ellenőrzése
if (!isset($_SESSION['jogosultsag']) || $_SESSION['jogosultsag'] !== 'admin') {
    header("Location: index.php");
    exit();
}

// Vélemény törlés
if (isset($_GET['torles'])) {
    $id = intval($_GET['torles']);
    $stmt = $conn->prepare("DELETE FROM velemenyek WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: admin_velemenyek.php");
    exit();
}

// Vélemények lekérdezése
$velemenyek = $conn->query("SELECT id, felhasznalonev, velemeny_szoveg, csillagok, datum FROM velemenyek ORDER BY datum DESC");
include 'startmenu.php';
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Vélemények Moderálása - 8Bite Admin</title>
    <link rel="stylesheet" href="css/windows95-vaporwave.css">
</head>
<body class="win95-bg">

<div class="admin-panel">
    <h1>🌟 Vélemények Moderálása</h1>

    <?php while ($row = $velemenyek->fetch_assoc()): ?>
        <div class="velemeny-kartya">
            <strong><?= htmlspecialchars($row['felhasznalonev']) ?></strong> –
            <?= str_repeat("⭐", (int)$row['csillagok']) ?><br>
            <em><?= nl2br(htmlspecialchars($row['velemeny_szoveg'])) ?></em><br>
            <small><?= $row['datum'] ?></small><br>
            <a href="?torles=<?= $row['id'] ?>" onclick="return confirm('Biztosan törlöd?')" class="torles-btn">🗑️ Törlés</a>
        </div>
    <?php endwhile; ?>
</div>

</body>
</html>
