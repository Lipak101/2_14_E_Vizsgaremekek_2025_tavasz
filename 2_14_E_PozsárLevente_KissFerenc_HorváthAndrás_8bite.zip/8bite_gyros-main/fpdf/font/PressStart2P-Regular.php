<?php
$type = 'TrueType';
$name = 'PressStart2P-Regular';
$desc = array(
    'Ascent' => 950,
    'Descent' => -350,
    'CapHeight' => 950,
    'Flags' => 32,
    'FontBBox' => '[-2 -8 678 996]',
    'ItalicAngle' => 0,
    'StemV' => 70,
    'MissingWidth' => 600,
);
$up = -100;
$ut = 50;
$cw = array_fill_keys(array_map('chr', range(32, 126)), 600);
$ttffile = 'PressStart2P-Regular.ttf';
$originalsize = 122196;
$fontkey = 'pressstart2p-regular';
?>
