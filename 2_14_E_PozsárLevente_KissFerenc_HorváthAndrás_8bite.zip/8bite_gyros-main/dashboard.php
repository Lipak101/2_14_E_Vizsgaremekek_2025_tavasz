<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vezérlőpult</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; padding: 50px; }
        .container { max-width: 400px; margin: auto; padding: 20px; border: 1px solid #ccc; border-radius: 10px; }
        a { text-decoration: none; color: white; background: red; padding: 10px; border-radius: 5px; display: inline-block; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Üdvözöllek, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>
        <p>Sikeresen bejelentkeztél.</p>
        <a href="logout.php">Kijelentkezés</a>
    </div>
</body>
</html>