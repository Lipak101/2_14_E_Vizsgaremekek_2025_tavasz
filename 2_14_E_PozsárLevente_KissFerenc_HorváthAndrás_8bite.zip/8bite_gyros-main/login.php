<?php
session_start();
include 'db.php';

header('Content-Type: application/json');

$response = [
    'siker' => false,
    'uzenet' => 'Ismeretlen hiba történt.'
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if (!empty($username) && !empty($password)) {
        $stmt = $conn->prepare("SELECT id, jelszo_hash, email FROM felhasznalok WHERE felhasznalonev = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows === 1) {
            $stmt->bind_result($user_id, $hashed_password, $email);
            $stmt->fetch();

            if (password_verify($password, $hashed_password)) {
                $_SESSION['felhasznalo_id'] = $user_id;
                $_SESSION['felhasznalonev'] = $username;
                $_SESSION['email'] = $email;

                // Admin jogosultság ellenőrzés
                $admin_stmt = $conn->prepare("SELECT COUNT(*) FROM adminok WHERE felhasznalo_id = ?");
                $admin_stmt->bind_param("i", $user_id);
                $admin_stmt->execute();
                $admin_stmt->bind_result($admin_count);
                $admin_stmt->fetch();
                $admin_stmt->close();

                $_SESSION['jogosultsag'] = ($admin_count > 0) ? 'admin' : 'felhasznalo';

                $response['siker'] = true;
                $response['uzenet'] = 'Sikeres bejelentkezés.';
            } else {
                $response['uzenet'] = '❌ Hibás jelszó!';
            }
        } else {
            $response['uzenet'] = '❌ Nincs ilyen felhasználó!';
        }

        $stmt->close();
    } else {
        $response['uzenet'] = '❌ Hiányzó adatok!';
    }
}

echo json_encode($response);
exit();
