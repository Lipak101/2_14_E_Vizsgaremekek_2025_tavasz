<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
include 'db.php';

if (isset($_SESSION['felhasznalo_id'], $_SESSION['felhasznalonev'], $_POST['velemeny'], $_POST['csillagok'])) {
    $user_id = $_SESSION['felhasznalo_id'];
    $felhasznalonev = $_SESSION['felhasznalonev'];
    $velemeny = htmlspecialchars($_POST['velemeny'], ENT_QUOTES, 'UTF-8');
    $csillagok = max(1, min(5, intval($_POST['csillagok'])));

    $stmt = $conn->prepare("INSERT INTO velemenyek (user_id, felhasznalonev, velemeny_szoveg, csillagok)
                            VALUES (?, ?, ?, ?)");
    if ($stmt === false) {
        die("❌ SQL előkészítési hiba: " . $conn->error);
    }

    $stmt->bind_param("issi", $user_id, $felhasznalonev, $velemeny, $csillagok);
    if ($stmt->execute()) {
        header("Location: index.php#velemenyek");
        exit();
    } else {
        die("❌ Végrehajtási hiba: " . $stmt->error);
    }
} else {
    // DEBUG segédlet:
    file_put_contents("debug_velemeny.txt", print_r([
        'SESSION' => $_SESSION,
        'POST' => $_POST
    ], true));

    die("⚠️ Hiányzó adatok vagy nincs bejelentkezve.");
}
