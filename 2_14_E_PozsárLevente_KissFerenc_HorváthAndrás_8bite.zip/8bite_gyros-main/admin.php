<?php
session_start();
if (!isset($_SESSION['jogosultsag']) || $_SESSION['jogosultsag'] !== 'admin') {
    header("Location: index.php");
    exit();
}
include 'startmenu.php';
?>



<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Admin felület - 8Bite</title>
    <link rel="stylesheet" href="css/windows95-vaporwave.css">
    <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">

    <style>
  body {
    background: url('img/admin-h.png') no-repeat center center fixed;
    background-size: cover;
    margin: 0;
    padding: 0;
    font-family: 'Press Start 2P', monospace;
    image-rendering: pixelated;
    color: #fff;
  }

  .admin-panel {
    background-color: rgba(0, 0, 0, 0.85);
    border: 3px solid #ff00ff;
    padding: 40px;
    max-width: 700px;
    margin: 100px auto;
    border-radius: 12px;
    box-shadow: 0 0 20px #ff66cc, 0 0 10px #66ffff inset;
    text-align: center;
  }

  .admin-panel h1 {
    font-size: 16px;
    color: #66ffff;
    margin-bottom: 30px;
    text-shadow: 2px 2px #ff00cc;
  }

  .admin-menu {
    list-style: none;
    padding: 0;
  }

  .admin-menu li {
    margin: 16px 0;
  }

  .admin-menu a {
    display: inline-block;
    background: #000;
    padding: 12px 20px;
    border: 2px solid #66ffff;
    border-radius: 6px;
    color: #ffccff;
    text-decoration: none;
    font-weight: bold;
    text-shadow: 1px 1px #000;
    transition: all 0.2s ease-in-out;
  }

  .admin-menu a:hover {
    background: #ff00cc;
    border-color: #ffffff;
    color: #000;
    box-shadow: 0 0 12px #ffffff;
  }
</style>
</head>
<body class="win95-bg">

<div class="admin-panel">
    <h1>🎛️ Admin felület - 8Bite</h1>
    <ul class="admin-menu">
        <li><a href="admin_velemenyek.php">🌟 Vélemények moderálása</a></li>
        <li><a href="admin_gyrosok.php">🌯 Gyros menü szerkesztése</a></li>
        <li><a href="admin_rendelesek.php">🧾 Rendelések megtekintése</a></li>
        <li><a href="chat_admin.php">💬 Élő chat figyelése</a></li>
    </ul>
</div>

</body>
</html>
