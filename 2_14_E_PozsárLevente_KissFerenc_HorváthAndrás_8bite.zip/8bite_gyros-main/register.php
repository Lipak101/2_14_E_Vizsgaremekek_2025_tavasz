<?php
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['felhasznalonev'], $_POST['jelszo'], $_POST['email'])) {
    $felhasznalonev = mysqli_real_escape_string($conn, trim($_POST['felhasznalonev']));
    $jelszo = $_POST['jelszo']; // nem escape-eljük, mert hash-elni fogjuk
    $email = mysqli_real_escape_string($conn, trim($_POST['email']));

    // Ellenőrzés: létezik-e már ilyen felhasználónév
    $ellenorzes = "SELECT * FROM felhasznalok WHERE felhasznalonev = '$felhasznalonev'";
    $eredmeny = mysqli_query($conn, $ellenorzes);

    if (mysqli_num_rows($eredmeny) > 0) {
        echo "Ez a felhasználónév már foglalt!";
    } else {
        // Jelszó hash-elése
        $jelszo_hash = password_hash($jelszo, PASSWORD_DEFAULT);

        // Mentés adatbázisba (csak a hash-t mentjük, nem a sima jelszót!)
        $beszuras = "INSERT INTO felhasznalok (felhasznalonev, email, jelszo_hash) VALUES ('$felhasznalonev', '$email', '$jelszo_hash')";

        if (mysqli_query($conn, $beszuras)) {
            session_start(); // biztos ami biztos
            $_SESSION['felhasznalonev'] = $felhasznalonev;
        
            echo "sikeres";
        } else {
            echo "Hiba a regisztráció során!";
        }        
    }
} else {
    echo "Hiányzó adatok!";
}
?>