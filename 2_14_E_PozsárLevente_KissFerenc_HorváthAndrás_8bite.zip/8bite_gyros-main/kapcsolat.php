<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <title>Kapcsolat – 8Bite</title>
  <link rel="stylesheet" href="css/kapcsolat.css">
</head>
<body>
<div class="navbar">
    <a href="index.php">Kezdőlap</a>
    <a href="etlap.php">Étlap</a>
    <a href="rolunk.php">Rólunk</a>
    <a href="kapcsolat.php">Kapcsolat</a>
</div>

<div class="win95-window-logo">
    <div class="win95-title-logo">Logo.exe</div>
    <img class="logo_img" src="img/logo.png" alt="logo">
</div>

  <div class="messenger-window">
    <div class="messenger-header">
      8Bite Kapcsolat Messenger
    </div>
    <div class="chat-box" id="chat-box">
      <!-- Ide töltődnek az üzenetek -->
    </div>
    <form class="input-bar" id="chat-form">
      <input type="text" name="uzenet" id="uzenet" placeholder="Írd ide az üzeneted..." required>
      <button type="submit">Küldés</button>
    </form>
  </div>

  <script>
    let utolsoTartalom = "";

    function frissitChat() {
      fetch('chat_lekerdez.php')
        .then(res => res.text())
        .then(data => {
          if (data !== utolsoTartalom) {
            const box = document.getElementById('chat-box');
            box.innerHTML = data;
            box.scrollTop = box.scrollHeight;

            if (utolsoTartalom !== "") {
              const hang = document.getElementById('pingSound');
              if (hang) hang.play();
            }

            utolsoTartalom = data;
          }
        });
    }

    document.getElementById('chat-form').addEventListener('submit', function(e) {
      e.preventDefault();
      const uzenet = document.getElementById('uzenet').value;
      fetch('chat_kuldes.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'uzenet=' + encodeURIComponent(uzenet)
      }).then(() => {
        document.getElementById('uzenet').value = '';
        frissitChat();
      });
    });

    setInterval(frissitChat, 3000);
    frissitChat();
  </script>

  <audio id="pingSound" src="sounds/MSN NEW EMAIL SOUNDS.mp3" preload="auto"></audio>
  <?php include 'startmenu.php'; ?>

</body>
</html>
