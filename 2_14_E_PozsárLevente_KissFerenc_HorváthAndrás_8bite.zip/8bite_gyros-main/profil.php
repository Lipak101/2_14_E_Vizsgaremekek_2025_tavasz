<?php
session_start();
include("db.php");

$id = $_SESSION['user_id'] ?? 0;
$siker = "";
$hiba = "";

// Adatok lekérdezése
$stmt = $conn->prepare("SELECT felhasznalonev, cim FROM felhasznalok WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->bind_result($felhasznalonev, $cim);
$stmt->fetch();
$stmt->close();

// Ha már van cím, próbáljuk darabolni
$iranyitoszam = $varos = $utca = $hazszam = "";

if (!empty($cim)) {
    if (preg_match('/^(\d{4})\s+([^,]+),\s*(.+?)\s+(\d+[a-zA-Z]?)$/', $cim, $m)) {
        [$full, $iranyitoszam, $varos, $utca, $hazszam] = $m;
    }
}

// Módosítás feldolgozása
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $uj_nev = $_POST['felhasznalonev'] ?? '';
    $iranyitoszam = $_POST['iranyitoszam'] ?? '';
    $varos = $_POST['varos'] ?? '';
    $utca = $_POST['utca'] ?? '';
    $hazszam = $_POST['hazszam'] ?? '';
    $uj_jelszo = $_POST['jelszo'] ?? '';

    $uj_cim = trim("$iranyitoszam $varos, $utca $hazszam");

    $query = "UPDATE felhasznalok SET felhasznalonev=?, cim=?";
    $types = "ssi";
    $params = [$uj_nev, $uj_cim];

    if (!empty($uj_jelszo)) {
        $uj_hash = password_hash($uj_jelszo, PASSWORD_DEFAULT);
        $query .= ", jelszo_hash=?";
        $types = "sssi";
        $params[] = $uj_hash;
    }

    $query .= " WHERE id=?";
    $params[] = $id;

    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);

    if ($stmt->execute()) {
        $siker = "✅ Profil frissítve!";
        $_SESSION['felhasznalonev'] = $uj_nev;
    } else {
        $hiba = "❌ Hiba a mentés során!";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Profil – 8Bite</title>
    <link rel="stylesheet" href="css/etlap.css">
</head>
<body>
<?php include 'startmenu.php'; ?>

<div class="win95-window">
    <div class="win95-title">👤 Profil szerkesztése – <?= htmlspecialchars($_SESSION['felhasznalonev'] ?? 'N/A') ?></div>
    <div class="menu-items" style="justify-content: center;">
        <form method="POST" style="background: #fff; border: 2px solid #000; padding: 20px; width: 320px; box-shadow: inset 2px 2px #fff, inset -2px -2px #808080; color: #000; font-family: 'Press Start 2P', cursive; font-size: 10px;">
            <?php
            if (!empty($hiba)) echo "<p style='color:red;'>$hiba</p>";
            if (!empty($siker)) echo "<p style='color:green;'>$siker</p>";
            ?>

            <label>Felhasználónév:<br>
                <input type="text" name="felhasznalonev" value="<?= htmlspecialchars($felhasznalonev) ?>" required style="width:100%; margin-bottom:10px;">
            </label><br>

            <label>Irányítószám:<br>
                <input type="text" name="iranyitoszam" value="<?= htmlspecialchars($iranyitoszam) ?>" style="width:100%; margin-bottom:10px;">
            </label><br>

            <label>Város:<br>
                <input type="text" name="varos" value="<?= htmlspecialchars($varos) ?>" style="width:100%; margin-bottom:10px;">
            </label><br>

            <label>Utca:<br>
                <input type="text" name="utca" value="<?= htmlspecialchars($utca) ?>" style="width:100%; margin-bottom:10px;">
            </label><br>

            <label>Házszám:<br>
                <input type="text" name="hazszam" value="<?= htmlspecialchars($hazszam) ?>" style="width:100%; margin-bottom:10px;">
            </label><br>

            <label>Új jelszó (ha változik):<br>
                <input type="password" name="jelszo" style="width:100%; margin-bottom:10px;">
            </label><br>

            <button type="submit" class="kosar-btn" style="width:100%;">💾 Mentés</button>
        </form>
    </div>
</div>
</body>
</html>
