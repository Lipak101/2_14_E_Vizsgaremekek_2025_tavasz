<?php
session_start();

// Egyszerű példa: fix felhasználónév és jelszó
$valid_username = "admin";
$valid_password = "1234"; // Biztonsági okokból használj hash-t adatbázisban

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username === $valid_username && $password === $valid_password) {
        $_SESSION['username'] = $username;
        header("Location: dashboard.php");
        exit();
    } else {
        header("Location: login.php?error=Hibás felhasználónév vagy jelszó!");
        exit();
    }
} else {
    header("Location: login.php");
    exit();
}
?>