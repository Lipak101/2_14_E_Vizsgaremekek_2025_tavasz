<?php
session_start();

$id = $_POST['id']; // = menu.id
$ar = $_POST['ar'];
$kep = $_POST['kep'];

if (!isset($_SESSION['kosar'])) {
    $_SESSION['kosar'] = [];
}

if (isset($_SESSION['kosar'][$id])) {
    $_SESSION['kosar'][$id]['db'] += 1;
} else {
    $_SESSION['kosar'][$id] = [
        'ar' => $ar,
        'db' => 1,
        'kep' => $kep
    ];
}

header("Location: ".$_SERVER['HTTP_REFERER']);
exit;
