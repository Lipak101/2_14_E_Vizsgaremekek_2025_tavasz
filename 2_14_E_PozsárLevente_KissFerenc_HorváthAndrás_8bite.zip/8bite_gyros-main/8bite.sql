-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2025 at 11:28 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `8bite`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminok`
--

CREATE TABLE `adminok` (
  `id` int(11) NOT NULL,
  `felhasznalo_id` int(11) DEFAULT NULL,
  `jogosultsag_szint` enum('admin','superadmin') DEFAULT 'admin'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adminok`
--

INSERT INTO `adminok` (`id`, `felhasznalo_id`, `jogosultsag_szint`) VALUES
(2, 5, 'superadmin');

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `id` int(11) NOT NULL,
  `felado` enum('user','admin') NOT NULL,
  `uzenet` text NOT NULL,
  `ido` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`id`, `felado`, `uzenet`, `ido`) VALUES
(1, 'admin', 'Üdvözlünk a 8Bite gyrosozó élő chatjén! Írj nekünk bátran!', '2025-04-02 16:36:12'),
(16, '', 'Üdvzölet!', '2025-04-20 21:27:36');

-- --------------------------------------------------------

--
-- Table structure for table `desszertek`
--

CREATE TABLE `desszertek` (
  `id` int(11) NOT NULL,
  `nev` varchar(100) NOT NULL,
  `leiras` text DEFAULT NULL,
  `ar` int(11) NOT NULL,
  `kep` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `desszertek`
--

INSERT INTO `desszertek` (`id`, `nev`, `leiras`, `ar`, `kep`) VALUES
(1, 'Portal Pite', 'Vaníliás sajttorta málnazselével és csokis kekszalappal', 1190, 'images/portal-pite.jpg'),
(2, 'Dark Souls Brownie', 'Tripla csokis brownie karamellöntettel', 1290, 'images/dark-souls-brownie.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `felhasznalok`
--

CREATE TABLE `felhasznalok` (
  `id` int(11) NOT NULL,
  `felhasznalonev` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `regisztracio_datum` datetime DEFAULT current_timestamp(),
  `jelszo` varchar(255) NOT NULL,
  `jelszo_hash` varchar(255) NOT NULL,
  `cim` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `felhasznalok`
--

INSERT INTO `felhasznalok` (`id`, `felhasznalonev`, `email`, `regisztracio_datum`, `jelszo`, `jelszo_hash`, `cim`) VALUES
(5, 'admin', 'admin@8bite.hu', '2025-04-02 20:51:45', '', '$2y$10$FbWHop.trrM2rEpygAPsR.ssvO2FAQXSiQU.lr1XVX7N.F3Dp456i', NULL),
(6, 'LeVY', 'asdasd@asd.asd', '2025-04-11 19:52:49', '', '$2y$10$9YKqkV8EQBGOXMLH1kulkOTwEqEqtF20Fw6suhzcWPWUpfN9QBunC', '2339 Taktaharkány, Ferenc utca 3'),
(8, 'asd123', 'asd@asd.asd', '2025-04-20 21:14:27', '', '$2y$10$hL01qoSUGNpwBFc1t0rbXOAPbUIe9Kgdo0iiNNdzl59p4zo6FYXqO', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `italok`
--

CREATE TABLE `italok` (
  `id` int(11) NOT NULL,
  `nev` varchar(100) NOT NULL,
  `leiras` text DEFAULT NULL,
  `ar` int(11) NOT NULL,
  `kep` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `italok`
--

INSERT INTO `italok` (`id`, `nev`, `leiras`, `ar`, `kep`) VALUES
(1, 'Health Potion', 'Eper-limonádé mentalevéllel és citromkarikával', 890, 'images/health-potion.jpg'),
(2, 'Mana Potion', 'Áfonyás szénsavas ital lime-mal', 890, 'images/mana-potion.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `nev` varchar(100) NOT NULL,
  `leiras` text DEFAULT NULL,
  `ar` int(11) NOT NULL,
  `temakor` varchar(100) DEFAULT NULL,
  `kep` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `nev`, `leiras`, `ar`, `temakor`, `kep`) VALUES
(1, 'Counter-Chicken', 'Ropogós rántott csirkehús gyrosban, chilis-fokhagymás szósz, uborka, hasábburgonya pitában', 2490, 'FPS', 'img/counter-chicken.png'),
(2, 'Smoke Wrap', 'Füstölt húsos pita chilis majonézzel', 2390, 'FPS', 'img/smoke-wrap.png'),
(3, 'Counter-Chicken', 'Ropogós rántott csirkehús gyrosban, chilis-fokhagymás szósz, uborka, hasábburgonya pitában', 2490, 'FPS', 'img/counter-chicken.png'),
(4, 'Smoke Wrap', 'Füstölt húsos pita chilis majonézzel', 2390, 'FPS', 'img/smoke-wrap.png'),
(5, 'Flashbang Fries', 'Extra csípős sültkrumpli jalapeñóval', 1090, 'FPS', 'img/flashbang-fries.png'),
(6, 'Ultimate Payload', 'Extra nagy gyros, kétféle hús, dupla szósz', 2690, 'FPS', 'img/ultimate-payload.png'),
(7, 'Quickscope Quesadilla', 'Csirkés, sajtos, lapos tortilla wrap', 2190, 'FPS', 'img/quickscope-quesadilla.png'),
(8, 'Elven Wrap', 'Könnyed csirkehús, mézes-mustáros öntet', 2290, 'Fantasy RPG', 'img/elven-wrap.png'),
(9, 'Dragon’s Breath Gyros', 'Pokolian csípős marhahús', 2490, 'Fantasy RPG', 'img/dragons-breath.png'),
(10, 'Potion Platter', 'Szószválogatás: tzatziki, BBQ, Diablo, mentás joghurt', 1490, 'Fantasy RPG', 'img/potion-platter.png'),
(11, 'Mana Fries', 'Kéksajtos szószos hasáb burgonya', 1190, 'Fantasy RPG', 'img/mana-fries.png'),
(12, 'Witcher\'s\' Kebab', 'Vadpácban érlelt fűszeres sertéshús gyros', 2390, 'Fantasy RPG', 'img/witchers-kebab.png'),
(13, 'Winner Wrap', 'Extra nagy gyros kétféle hússal', 2590, 'Battle Royale', 'img/winner-wrap.png'),
(14, 'Loot Box Lunch', 'Random gyros + köret + mini üdítő', 2690, 'Battle Royale', 'img/loot-box.png'),
(15, 'BlueZone Burger', 'Wrap-burger csípős szósszal', 2490, 'Battle Royale', 'img/bluezone-burger.png'),
(16, 'Drop-In Döner', 'Szaftos gyros gyorsétel stílusban', 2290, 'Battle Royale', 'img/dropin-doner.png'),
(17, 'Clutch Cone', 'Mini wrap falatok harapásnyi méretben', 1790, 'Battle Royale', 'img/clutch-cone.png'),
(18, 'CyberByte Gyros', 'Marhahús, neonzöld wasabi szósz, lilahagymával', 2490, 'Cyberpunk', 'img/cyberbyte.png'),
(19, 'Kernel Krunch', 'Baconös-sajtos csirkehús ropogtatva', 2390, 'Cyberpunk', 'img/kernel-krunch.png'),
(20, 'Blue Screen Sauce', 'Sajtszósz kék sajtból', 1190, 'Cyberpunk', 'img/blue-screen.png'),
(21, 'Firewall Falafel', 'Fűszeres vegán falafel gyros', 2190, 'Cyberpunk', 'img/firewall-falafel.png'),
(22, 'Alt+Meat Delete', 'Húspótlós BBQ gyros, tápiókás salátával', 2290, 'Cyberpunk', 'img/altmeat-delete.png'),
(23, 'Tetris-Tekercs', '4 színű mini wrap, különböző töltelékkel', 1990, 'Retro & Indie', 'img/tetris-tekercs.png'),
(24, 'PacMan Pockets', 'Sajttal töltött pita gombóc', 1490, 'Retro & Indie', 'img/pacman-pockets.png'),
(25, 'Stardew Wrapley', 'Házias csirkés wrap paradicsomszósszal', 2290, 'Retro & Indie', 'img/stardew-wrapley.png'),
(26, 'Sans’ Snack', 'Spicy tofu wrap, indie stílusban', 2190, 'Retro & Indie', 'img/sans-snack.png'),
(27, 'Cartridge Combo', 'Választható 3 kis tétel nosztalgia csomagban', 2590, 'Retro & Indie', 'img/cartridge-combo.png'),
(28, 'Doom Wrap', 'Kétféle chili, ghost pepper szósz', 2490, 'Hardcore', 'img/doom-wrap.png'),
(29, 'HP Drain Delight', 'Annyira csípős, hogy sírsz', 2390, 'Hardcore', 'img/hp-drain.png'),
(30, 'Permadeath Platter', '3 extra csípős wrap egy tálon', 2890, 'Hardcore', 'img/permadeath.png'),
(31, 'Silent Gyros', 'Fokhagymás sertéshús fekete pitában', 2290, 'Hardcore', 'img/silent-gyros.png'),
(32, 'Nemesis Nuggets', 'Csípős csirkefalatok mini gyrosba tekerve', 2090, 'Hardcore', 'img/nemesis-nuggets.png'),
(33, 'Comfy Cottage Wrap', 'Grillezett sajt, zöldségek, édes-mustáros öntet, friss pita', 1990, 'Chill & Cozy', 'img/comfy-cottage.png'),
(34, 'Island Life Gyros', 'Kókusztejes csirkemell, ananász salsa, salátalevél, könnyű pita', 2190, 'Chill & Cozy', 'img/island-life.png'),
(35, 'Sprout Roll', 'Vegán falafel, babcsíra, tahini-méz szósz, teljes kiőrlésű wrap', 2090, 'Chill & Cozy', 'img/sprout-roll.png'),
(36, 'Boba & Books Box', 'Mini desszertcsomag + Bubble tea', 1890, 'Chill & Cozy', 'img/boba-books.png'),
(37, 'The Sims SimSnack', 'Wrap sült zöldségekkel és feta sajttal + különleges mártogatós', 1990, 'Chill & Cozy', 'img/sims-snack.png'),
(38, 'Purrfect Bite', 'Sajtos, enyhén fűszeres mini pita', 1590, 'Chill & Cozy', 'img/purrfect-bite.png');

--
-- Triggers `menu`
--
DELIMITER $$
CREATE TRIGGER `menu_torles_naplo` BEFORE DELETE ON `menu` FOR EACH ROW BEGIN
    INSERT INTO menu_naplo (menu_id, nev, ar)
    VALUES (OLD.id, OLD.nev, OLD.ar);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `menu_naplo`
--

CREATE TABLE `menu_naplo` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) DEFAULT NULL,
  `nev` varchar(100) DEFAULT NULL,
  `ar` int(11) DEFAULT NULL,
  `torles_idopont` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `rendelesek`
--

CREATE TABLE `rendelesek` (
  `id` int(11) NOT NULL,
  `felhasznalo_id` int(11) DEFAULT NULL,
  `menu_id` int(11) DEFAULT NULL,
  `darab` int(11) DEFAULT 1,
  `rendeles_idopont` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rendelesek`
--

INSERT INTO `rendelesek` (`id`, `felhasznalo_id`, `menu_id`, `darab`, `rendeles_idopont`) VALUES
(1, 5, NULL, 1, '2025-04-15 13:18:28');

--
-- Triggers `rendelesek`
--
DELIMITER $$
CREATE TRIGGER `rendeles_naplozas` AFTER INSERT ON `rendelesek` FOR EACH ROW BEGIN
    INSERT INTO rendeles_naplo (rendeles_id, felhasznalo_id, menu_id, darab)
    VALUES (NEW.id, NEW.felhasznalo_id, NEW.menu_id, NEW.darab);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `rendeles_naplo`
--

CREATE TABLE `rendeles_naplo` (
  `id` int(11) NOT NULL,
  `rendeles_id` int(11) DEFAULT NULL,
  `felhasznalo_id` int(11) DEFAULT NULL,
  `menu_id` int(11) DEFAULT NULL,
  `darab` int(11) DEFAULT NULL,
  `naplo_datum` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rendeles_naplo`
--

INSERT INTO `rendeles_naplo` (`id`, `rendeles_id`, `felhasznalo_id`, `menu_id`, `darab`, `naplo_datum`) VALUES
(1, 1, 5, NULL, 1, '2025-04-15 13:18:28');

-- --------------------------------------------------------

--
-- Table structure for table `velemenyek`
--

CREATE TABLE `velemenyek` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `felhasznalonev` varchar(100) NOT NULL,
  `profilkep` varchar(255) DEFAULT 'default.png',
  `velemeny_szoveg` text NOT NULL,
  `csillagok` int(11) NOT NULL CHECK (`csillagok` between 1 and 5),
  `datum` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `velemenyek`
--

INSERT INTO `velemenyek` (`id`, `user_id`, `felhasznalonev`, `profilkep`, `velemeny_szoveg`, `csillagok`, `datum`) VALUES
(8, 5, 'admin', 'default.png', 'Nagyon jól müködik a weboldal!', 5, '2025-04-20 23:22:39'),
(9, 6, 'levy', 'default.png', 'Nagyon jó', 4, '2025-04-20 23:23:27'),
(10, 8, 'asd123', 'default.png', 'asd', 3, '2025-04-20 23:23:53'),
(11, 5, 'admin', 'default.png', 'Írd meg a véleményed...', 5, '2025-04-20 23:24:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminok`
--
ALTER TABLE `adminok`
  ADD PRIMARY KEY (`id`),
  ADD KEY `felhasznalo_id` (`felhasznalo_id`);

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `desszertek`
--
ALTER TABLE `desszertek`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `felhasznalok`
--
ALTER TABLE `felhasznalok`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `italok`
--
ALTER TABLE `italok`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_naplo`
--
ALTER TABLE `menu_naplo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rendelesek`
--
ALTER TABLE `rendelesek`
  ADD PRIMARY KEY (`id`),
  ADD KEY `felhasznalo_id` (`felhasznalo_id`),
  ADD KEY `menu_id` (`menu_id`);

--
-- Indexes for table `rendeles_naplo`
--
ALTER TABLE `rendeles_naplo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `velemenyek`
--
ALTER TABLE `velemenyek`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminok`
--
ALTER TABLE `adminok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `desszertek`
--
ALTER TABLE `desszertek`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `felhasznalok`
--
ALTER TABLE `felhasznalok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `italok`
--
ALTER TABLE `italok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `menu_naplo`
--
ALTER TABLE `menu_naplo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rendelesek`
--
ALTER TABLE `rendelesek`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `rendeles_naplo`
--
ALTER TABLE `rendeles_naplo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `velemenyek`
--
ALTER TABLE `velemenyek`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `adminok`
--
ALTER TABLE `adminok`
  ADD CONSTRAINT `adminok_ibfk_1` FOREIGN KEY (`felhasznalo_id`) REFERENCES `felhasznalok` (`id`);

--
-- Constraints for table `rendelesek`
--
ALTER TABLE `rendelesek`
  ADD CONSTRAINT `rendelesek_ibfk_1` FOREIGN KEY (`felhasznalo_id`) REFERENCES `felhasznalok` (`id`),
  ADD CONSTRAINT `rendelesek_ibfk_2` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`);

--
-- Constraints for table `velemenyek`
--
ALTER TABLE `velemenyek`
  ADD CONSTRAINT `velemenyek_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `felhasznalok` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
