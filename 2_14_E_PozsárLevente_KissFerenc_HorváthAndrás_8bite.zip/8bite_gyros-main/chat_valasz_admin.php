<?php
session_start();
require_once "db.php";

// Csak admin küldhet választ
if (!isset($_SESSION['jogosultsag']) || $_SESSION['jogosultsag'] !== 'admin') {
    http_response_code(403);
    exit('Nincs jogosultság.');
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['uzenet']) && !empty($_POST['uzenet'])) {
    $uzenet = trim($_POST['uzenet']);
    $stmt = $conn->prepare("INSERT INTO chat (felado, uzenet) VALUES ('admin', ?)");
    $stmt->bind_param("s", $uzenet);
    $stmt->execute();
}
?>
