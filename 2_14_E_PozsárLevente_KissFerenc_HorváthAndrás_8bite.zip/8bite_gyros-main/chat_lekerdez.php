<?php
$kapcsolat = new mysqli("localhost", "root", "", "8bite");
if ($kapcsolat->connect_error) {
    die("Kapcsolódási hiba: " . $kapcsolat->connect_error);
}

$sql = "SELECT * FROM chat ORDER BY ido ASC";
$eredmeny = $kapcsolat->query($sql);

while ($sor = $eredmeny->fetch_assoc()) {
    $felado = $sor['felado'];
    $uzenet = htmlspecialchars($sor['uzenet']);
    $profil = '';

    if ($felado === 'admin') {
        $nev = '8Bite Admin';
        $profil = "<img src='css/admin-.png' class='profil' alt='admin avatar' />";
    } else {
        // A felado mező maga tartalmazza a felhasználónevet
        $nev = htmlspecialchars($felado);
    }

    echo "
      <div class='uzenet {$felado}'>
        {$profil}
        <div><strong>{$nev}:</strong> {$uzenet}</div>
      </div>
    ";
}
?>
