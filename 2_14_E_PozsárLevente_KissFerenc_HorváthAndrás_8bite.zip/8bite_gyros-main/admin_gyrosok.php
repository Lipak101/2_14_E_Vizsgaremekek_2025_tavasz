<?php
session_start();
require_once "db.php";

// Csak admin léphet be
if (!isset($_SESSION['jogosultsag']) || $_SESSION['jogosultsag'] !== 'admin') {
    header("Location: index.php");
    exit();
}

include 'startmenu.php';

// A gyrosokat a 'menu' táblából kérjük le (a 8bite adatbázisból)
$gyrosok = $conn->query("SELECT * FROM menu ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Gyros menü szerkesztése - Admin</title>
    <link rel="stylesheet" href="css/windows95-vaporwave.css">
</head>
<body class="win95-bg">

<?php if (isset($_GET['uzenet']) && $_GET['uzenet'] === 'sikeres_torles'): ?>
    <div class="ablak win95-box" style="margin: 15px auto; border: 2px solid #000080; background: #C0C0C0; padding: 10px; max-width: 500px;">
        <div class="ablak-fejlec" style="background: #000080; color: white; padding: 5px;">
            <strong>8Bite Rendszerüzenet</strong>
        </div>
        <div class="ablak-tartalom" style="padding: 10px; background: #E0E0E0;">
            ✅ A gyros sikeresen törölve lett!
        </div>
    </div>
<?php endif; ?>

<div class="admin-panel">
    <h1>🌯 Gyros Menü Szerkesztése</h1>
    <a href="gyros_hozzaadasa.php" class="admin-button">➕ Új gyros hozzáadása</a>

    <?php while($row = $gyrosok->fetch_assoc()): ?>
        <div class="velemeny-kartya">
            <strong><?= htmlspecialchars($row['nev']) ?></strong> – <?= $row['ar'] ?> Ft<br>
            <em><?= htmlspecialchars($row['leiras']) ?></em><br>
            <a href="gyros_modositas.php?id=<?= $row['id'] ?>">✏️ Módosítás</a> |
            <a href="gyros_torles.php?id=<?= $row['id'] ?>" onclick="return confirm('Biztosan törlöd?')">🗑️ Törlés</a>
        </div>
    <?php endwhile; ?>
</div>

</body>
</html>
