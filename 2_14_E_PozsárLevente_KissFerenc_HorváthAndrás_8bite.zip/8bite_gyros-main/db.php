<?php
$host = "localhost";
$user = "root";
$pass = ""; // ha van jelszavad, ide írd be
$db = "8bite"; // az SQL fájlod neve alapján

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Nem sikerült csatlakozni: " . mysqli_connect_error());
}
?>