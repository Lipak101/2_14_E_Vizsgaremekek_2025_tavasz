<?php
session_start();

if (isset($_GET['nev']) && isset($_GET['mod'])) {
    $nev = $_GET['nev'];
    $mod = $_GET['mod'];

    if (isset($_SESSION['kosar'][$nev])) {
        switch ($mod) {
            case 'novel':
                $_SESSION['kosar'][$nev]['db'] += 1;
                break;
            case 'csokkent':
                $_SESSION['kosar'][$nev]['db'] -= 1;
                if ($_SESSION['kosar'][$nev]['db'] <= 0) {
                    unset($_SESSION['kosar'][$nev]);
                }
                break;
            case 'torol':
                unset($_SESSION['kosar'][$nev]);
                break;
        }
    }
}

header("Location: " . $_SERVER['HTTP_REFERER']);
exit;
?>