<?php
session_start();
require_once "db.php";

// Csak bejelentkezett felhasználó küldhet üzenetet
if (!isset($_SESSION['felhasznalonev'])) {
    http_response_code(403);
    exit('Nem vagy bejelentkezve.');
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['uzenet'])) {
    $uzenet = trim($_POST['uzenet']);
    $felado = $_SESSION['felhasznalonev'];
    $stmt = $conn->prepare("INSERT INTO chat (felado, uzenet) VALUES (?, ?)");
    $stmt->bind_param("ss", $felado, $uzenet);
    $stmt->execute();
}
?>
