<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHP_mail/PHPMailer.php';
require 'PHP_mail/SMTP.php';
require 'PHP_mail/Exception.php';

$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = 'smtp.example.com';  // saját SMTP szerver
    $mail->SMTPAuth = true;
    $mail->Username = 'info@8bite.hu';
    $mail->Password = 'JELSZÓ';
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $mail->setFrom('info@8bite.hu', '8Bite Gyros');
    $mail->addAddress($email); // vásárló emailje

    $mail->isHTML(true);
    $mail->Subject = '8Bite rendelésed számlája';
    $mail->Body    = 'Köszönjük rendelésed! A számlát csatoltuk PDF-ben. Jó étvágyat kívánunk!';

    $mail->addAttachment($szamla_fajl);
    $mail->send();
} catch (Exception $e) {
    error_log("Sikertelen email: {$mail->ErrorInfo}");
}
?>
