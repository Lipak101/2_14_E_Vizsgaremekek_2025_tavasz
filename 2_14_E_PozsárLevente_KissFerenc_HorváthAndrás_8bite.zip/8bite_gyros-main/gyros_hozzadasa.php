<?php
session_start();
require_once "config.php";
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header("Location: index.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nev = $_POST['nev'];
    $leiras = $_POST['leiras'];
    $ar = intval($_POST['ar']);
    $stmt = $conn->prepare("INSERT INTO gyrosok (nev, leiras, ar) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $nev, $leiras, $ar);
    $stmt->execute();
    header("Location: admin_gyrosok.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Új gyros hozzáadása</title>
    <link rel="stylesheet" href="css/windows95-vaporwave.css">
</head>
<body class="win95-bg">
<div class="admin-panel">
    <h1>➕ Új Gyros Hozzáadása</h1>
    <form method="post">
        Név: <input type="text" name="nev" required><br>
        Leírás: <textarea name="leiras"></textarea><br>
        Ár (Ft): <input type="number" name="ar" required><br>
        <input type="submit" value="Mentés">
    </form>
</div>
</body>
</html>
