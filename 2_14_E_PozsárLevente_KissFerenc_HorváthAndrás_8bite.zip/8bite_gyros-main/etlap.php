<?php
session_start();
$mysqli = new mysqli("localhost", "root", "", "8bite");
$mysqli->set_charset("utf8");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($_POST['kosarba'])) {
    $_SESSION['kosar'][] = [
      'nev' => $_POST['nev'],
      'ar' => $_POST['ar']
    ];
  }
  if (isset($_POST['torles'])) {
    unset($_SESSION['kosar'][$_POST['index']]);
    $_SESSION['kosar'] = array_values($_SESSION['kosar']);
  }
  if (isset($_POST['megrendel'])) {
    $_SESSION['kosar'] = [];
    echo "<script>alert('Rendelés sikeresen leadva!');</script>";
  }
}

function renderMenu($result, $cim) {
  echo "<div class='win95-window'>";
  echo "<div class='win95-title'>$cim</div><div class='menu-items'>";
  while ($row = $result->fetch_assoc()) {
    echo "<div class='menu-card'>";
    echo "<img src='{$row['kep']}' alt='{$row['nev']}'>";
    echo "<h3>{$row['nev']}</h3>";
    echo "<p>{$row['leiras']}</p>";
    echo "<span class='ar'>{$row['ar']} Ft</span><br>";
    echo "<form method='POST' action='kosar_hozzadas.php'>";
    echo "<input type='hidden' name='id' value='{$row['id']}'>";
    echo "<input type='hidden' name='ar' value='{$row['ar']}'>";
    echo "<input type='hidden' name='kep' value='{$row['kep']}'>";
    echo "<button type='submit' class='kosar-btn' onclick='playClick()'>Kosárba</button>";
    echo "</form>";
    echo "</div>";
  }
  echo "</div></div>";
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <title>8BITE Étlap</title>
  <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/etlap.css">
</head>
<body>
  <div class="navbar">
    <a href="index.php">Kezdőlap</a>
    <a href="etlap.php">Étlap</a>
    <a href="rolunk.php">Rólunk</a>
    <a href="kapcsolat.php">Kapcsolat</a>
  </div>

<?php
$gyrosok = $mysqli->query("SELECT * FROM menu");
renderMenu($gyrosok, "Gamer Gyrosok");

$desszertek = $mysqli->query("SELECT * FROM desszertek");
renderMenu($desszertek, "Desszertek");

$italok = $mysqli->query("SELECT * FROM italok");
renderMenu($italok, "Italok");
?>
<?php include 'startmenu.php'; ?>
</body>
</html>
