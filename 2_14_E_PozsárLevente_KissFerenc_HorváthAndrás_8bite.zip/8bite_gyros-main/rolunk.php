<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <title>Rólunk – 8Bite</title>
  <link rel="stylesheet" href="css/rolunk.css">
</head>
<body>


  <div class="navbar">
    <a href="index.php">Kezdőlap</a>
    <a href="etlap.php">Étlap</a>
    <a href="rolunk.php">Rólunk</a>
    <a href="kapcsolat.php">Kapcsolat</a>
  </div>

  <div class="win95-window-logo">
    <div class="win95-title-logo">Logo.exe</div>
    <img class="logo_img" src="img/logo.png" alt="logo">
</div>

  <div class="rolunk-ablak">
    <div class="rolunk-fejlec">💾 8Bite – Rólunk</div>
    <div class="rolunk-tartalom">
    <div class="rolunk-tartalom">
  <strong>A 8Bite nem csak egy gyrosozó.</strong> Ez egy retró univerzum, ahol a pita és a pixel egyesül.  
  Egy hely, ahol az éhséget nem simán csillapítjuk — hanem headshotoljuk.  
  <br><br>

  Itt minden úgy van kialakítva, mintha a régi LAN-partyk újraéledtek volna:  
  floppy-s hangok a háttérben, Windows 95 ablakok a dizájnban,  
  és olyan gyrosok, amitől egy Protoss is teleportálna a pulthoz. 🌯🖱️
  <br><br>

  🎮 <strong>Miért más a 8Bite?</strong><br>
  – Mert nálunk Ferenc, Levente és András nemcsak gyrost adnak — ők <em>veteránok a pixelek frontján</em>.<br>
  – Mert a pult mögött headsetes figurák dolgoznak, akik úgy szervíroznak, mint egy jól összehangolt CS 1.6 team.<br>
  – Mert nálunk a pita <strong>nem fagy le</strong>, mint a régi Pentium, hanem <strong>töltve van, forrón, pontosan, GG-re készen</strong>.
  <br><br>

  👾 <strong>Alapanyagok?</strong>  
  Olyan frissek, mint amikor újraindítod a Quake-et God Mode-ban.<br>

  🧠 <strong>Dizájn?</strong>  
  Színtiszta Windows 95 x Doom HUD. Igen, van „Start Menü” érzésed, miközben öntöd rá a szószt.<br>

  🚀 <strong>Hangulat?</strong>  
  Olyan, mint amikor LAN-on a barátaiddal épp veritek a zombikat...  
  csak közben gyrost esztek, és András egy DOOM démon sapkában a háttérből integet.
  <br><br>

  💬 <strong>Idézet egy vendégtől:</strong><br>
  <em>"Olyan, mintha a gyros egy cheat code lenne az éhség ellen.  
  Itt nem simán eszel. Itt pályát teljesítesz."</em>
  <br><br>

  <strong>Térj be hozzánk.</strong><br>
  Gyorsan kiszolgálunk, finoman betöltünk — és amíg te falatozol,  
  addig a nosztalgia <strong>UPGRADE-el téged!</strong> 🧑‍💻🌯✨
</div>
    </div>

    <div style="text-align:center; margin-top: 20px;">
  <img src="css/csapatfoto.png" alt="8Bite csapat" style="width:100%; max-width:520px; border:2px solid #000080; border-radius:6px;">
  <p style="margin-top: 8px; font-style: italic;">„A Pokol kapui megnyíltak… és gyrost kértek. Ferenc, Levente és András szolgálnak!”</p>
</div>
<div style="margin-top: 30px; text-align: center;">
  <h3 style="color: #000080; font-family: 'Press Start 2P', monospace; font-size: 12px; margin-bottom: 12px;">
    📍 Hol találsz minket?
  </h3>
  <div style="border: 2px solid #000080; border-radius: 6px; overflow: hidden; display: inline-block;">
    <iframe 
      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2692.120890798087!2d18.2638364!3d47.2553171!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x476a2100245fcba5%3A0xf09ead789bf7dea9!2sKincsesb%C3%A1nyai%20Nether%20kapu!5e0!3m2!1shu!2shu!4v1712724947797!5m2!1shu!2shu" 
      width="520" 
      height="300" 
      style="border:0;" 
      allowfullscreen="" 
      loading="lazy" 
      referrerpolicy="no-referrer-when-downgrade">
    </iframe>
  </div>
</div>
  </div>
  <?php include 'startmenu.php'; ?>

</body>
</html>
